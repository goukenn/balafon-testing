<?php


$tab  = [1,2,3, 3, 5];

$indexes = array_rand($tab, 2);

igk_wln_e($indexes);