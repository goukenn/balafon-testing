<?php



\IGK\Controllers\ControllerTypeBase::GetAdditionalDefaultViewContent();