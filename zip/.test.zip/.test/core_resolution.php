<?php

// $r =  igk_io_get_relativepath(
//     "/src/public/assets/_lib_/Scripts/igk.js",
//     "/src/application/Lib/igk/Scripts/igk.js"
// );


// // "../../../C/B/O",
// $g =  igk_io_get_relativepath("/A/B/C", "/C/B/O"); // "../../../C/B/O"
//$x =  igk_io_get_relativepath("/A/B/C", "/A/C/D");

igk_wln_e(
    igk_io_get_relativepath("/A/B/C/E", "/A/C/D/E"),
//     igk_io_get_relativepath(
//             "/src/public/assets/_lib_/Scripts/igk.js",
//             "/src/application/Lib/igk/Scripts/igk.js"
//     ),
// // //     $r, 
// // // $g,
// igk_io_get_relativepath("/A/B/C", "/A/B/D"),
// igk_io_get_relativepath("/A/B/C/E/F/M/N", "/A/C/D"),
// igk_io_get_relativepath("/A/B/C/D/E", "/A/F/G/H/I"),
// igk_io_get_relativepath("/A/B/C/D/", "/E/F/G/H")
);