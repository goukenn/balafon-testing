<?php

use IGK\System\DataArgs;
use IGK\System\IO\StringBuilder;
use IGK\System\Net\MailDocument;

$ctrl = bantubeatController::ctrl();
$g = "data";
$sb = new StringBuilder;
$n = new MailDocument();
$n->article($ctrl,'registrationMail', new DataArgs([
    'firstName'=>$g,
    'activate_uri'=>$ctrl->getAppUri("api/users/activate")
    'firstName'=>$g->clFirstName,
    'lastName'=>$g->clLastName
]));
$sb->appendLine($n->render());


echo $sb->__toString();

