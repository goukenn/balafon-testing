<div><?php

igk_express_var("x") = 110;
if (true):
?>
<li>Ok</li>
<?php endif; ?>
</div>