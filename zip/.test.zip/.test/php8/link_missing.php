<?php

use IGK\System\Html\Dom\HtmlCssLinkNode;

$g = new HtmlCssLinkNode("/assets/styles/balafon.css");

igk_wln_e($g->render());