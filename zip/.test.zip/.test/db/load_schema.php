<?php
// balafon --run ./.test/db/load_schema.php
use IGK\Database\DbSchemas;
use IGK\System\Console\Logger;

$fb = igk_require_module(igk\social\facebook::class);

// $migrations = IGKModuleListMigration::CreateModulesMigration();
list($file) = $params; 
if ($r = DbSchemas::LoadSchema($file)){
    // $migrations->Migrate();
    print_r(array_keys((array)$r->tables["tbigk_products"]->columnInfo));
    // print_r(json_encode($r)); 
    // print_r($r);
}else{
    Logger::danger("failed");
}
exit;