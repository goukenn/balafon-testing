<?php
 
use IGK\Models\PhoneBooks;
use IGK\Models\PhoneBookTypes;
use IGK\Models\PhoneBookUserAssociations;
use IGK\System\Constants\PhonebookTypeNames;

$user = igk_get_user_bylogin('cbondje@igkdev.com');

$g = $user->getPhoneBookEntryByType(); 

igk_wln_e($g);