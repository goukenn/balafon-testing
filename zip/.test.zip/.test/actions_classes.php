<?php

use IGK\Helper\ActionHelper;

$tab = ActionHelper::GetActionClasses($ctrl);

igk_wln_e("result", $ctrl, $tab);