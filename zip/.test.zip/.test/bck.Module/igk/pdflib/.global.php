<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/pdflib/.global.php
// @date: 20220309 14:42:33

// + module entry file 
