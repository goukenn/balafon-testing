<?php

// @author: C.A.D. BONDJE DOUE
// @filename: PDFConstants.php
// @date: 20220310 17:35:14
// @desc: pdflib constants

namespace igk\pdflib;

class PDFConstants{
    public const NS_PREFIX = "igk:pdflib-";
}
