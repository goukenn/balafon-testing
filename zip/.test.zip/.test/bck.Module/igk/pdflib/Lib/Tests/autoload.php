<?php
// @author: C.A.D. BONDJE DOUE
// @date: 20220309 14:42:33

$_ENV["igk_test_module"] = \igk\pdflib::class;




require_once $_ENV["IGK_APP_DIR"]."/Lib/igk/Lib/Tests/autoload.php";
