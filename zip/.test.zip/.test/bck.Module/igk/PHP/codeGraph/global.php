<?php
// @author: C.A.D. BONDJE DOUE
// @file: %packages%/Modules/igk/PHP/codeGraph/global.php
// @date: 20211110 10:07:48

// + module entry file 
