<?php

// author : C.A.D. BONDJE DOUE
// description : armonic balafon's module
// file : .global.php


!defined("IGK_TREAT_LIB") && define("IGK_TREAT_LIB", 1);
 
