<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/Theme/.global.php
// @date: 20220215 10:00:11

// + module entry file 
