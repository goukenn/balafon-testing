<?php

namespace igk\BMC;

abstract class NodeFilter extends \IGK\System\Html\HtmlNodeFilterBase{

    protected static function FilterDir(){
        return __DIR__;
    }

}