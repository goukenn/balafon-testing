<?php
// @author: C.A.D. BONDJE DOUE
// @date: 20230310 13:24:51
namespace igk\nodePackageManager\Tests;

use IGK\Tests\BaseTestCase;

///<summary></summary>
/**
* 
* @package igk\nodePackageManager\Tests
*/
abstract class ModuleTestBase extends BaseTestCase{
	public static function setUpBeforeClass(): void{
	   igk_require_module(__NAMESPACE__);
	}
}