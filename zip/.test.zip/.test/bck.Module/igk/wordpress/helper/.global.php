<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igkwordpress/.global.php
// @date: 20221123 09:46:00

// + module entry file 
