# module igk\ios\SfSymbols

use apple icons - 
```php
igk_require_module(\igk\ios\SfSymbols:class);
```

