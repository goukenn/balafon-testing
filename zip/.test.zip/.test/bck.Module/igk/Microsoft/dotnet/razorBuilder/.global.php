<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/Microsoft/dotnet/razorBuilder/.global.php
// @date: 20220811 13:44:47

// + module entry file 
