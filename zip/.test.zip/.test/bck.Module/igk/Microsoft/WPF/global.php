<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/Microsoft/WPF/global.php
// @date: 20220207 14:42:57

// + module entry file 
