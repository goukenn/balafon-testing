<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/Microsoft/XAML/global.php
// @date: 20220207 14:46:30

// + module entry file 
