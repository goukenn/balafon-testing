<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/sass/.global.php
// @date: 20221005 06:48:29

// + module entry file 
