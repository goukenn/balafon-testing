** igk/msword
ms-word module utility 
@C.A.DBONDJEDOUE