<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/msword/global.php
// @desc: ms-word module utility
// @date: 20210708 17:47:25

// + module entry file 
