<?php


namespace igk\msword;

/**
 * file builder - 
 * @package igk\msword
 */
class File{
    public static function Touch($file){
        if ($h = fopen($file, "w+")){
            fwrite($h, chr(30));
            fclose($h);
        }
    }
}