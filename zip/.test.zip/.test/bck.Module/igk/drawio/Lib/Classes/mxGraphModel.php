<?php

// @author: C.A.D. BONDJE DOUE
// @filename: mxGraphModel.php
// @date: 20220503 19:38:28
// @desc: 

namespace igk\drawio;

/**
 * graphics model
 * @package igk\drawio
 * @property mixed $dx
 * @property mixed $dy 
 * @property mixed $grid
 * @property mixed $gridSize
 * @property mixed $guides 1
 * @property mixed $tooltips 1 
 * @property mixed $connect 1 
 * @property mixed $arrows
 * @property mixed $fold 
 * @property mixed $page 
 * @property mixed $pageScale 1 
 * @property mixed $pageWidth 
 * @property mixed $pageHeight 
 * @property mixed $math 
 * @property mixed $shadow
 */
class mxGraphModel extends drawIONode
{
    private $m_root;
    /**
    * get Page
    */
    public function getPage(){
        return $this["page"];
    }
    /**
    * set Page
    */
    public function setPage($v){
        $this["page"] = $v;
        return $this;
    }
    /**
    * get Arrows
    */
    public function getArrows(){
        return $this["arrows"];
    }
    /**
    * set Arrows
    */
    public function setArrows($v){
        $this["arrows"] = $v;
        return $this;
    }
    /**
    * get Connect
    */
    public function getConnect(){
        return $this["connect"];
    }
    /**
    * set Connect
    */
    public function setConnect($v){
        $this["connect"] = $v;
        return $this;
    }
    /**
     * get Shadow
     */
    public function getShadow()
    {
        return $this["shadow"];
    }
    /**
     * set Shadow
     */
    public function setShadow($v)
    {
        $this["shadow"] = $v;
        return $this;
    }
    /**
     * get Tooltips
     */
    public function getTooltips()
    {
        return $this["tooltips"];
    }
    /**
     * set Tooltips
     */
    public function setTooltips($v)
    {
        $this["tooltips"] = $v;
        return $this;
    }
    /**
     * get Guides
     */
    public function getGuides()
    {
        return $this["guides"];
    }
    /**
     * set Guides
     */
    public function setGuides($v)
    {
        $this["guides"] = $v;
        return $this;
    }
    /**
     * get grid
     */
    public function getgrid()
    {
        return $this["grid"];
    }
    /**
     * set grid
     */
    public function setgrid($v)
    {
        $this["grid"] = $v;
        return $this;
    }
    /**
     * get GridSize
     */
    public function getGridSize()
    {
        return $this["gridSize"];
    }
    /**
     * set GridSize
     */
    public function setGridSize($v)
    {
        $this["gridSize"] = $v;
        return $this;
    }
    /**
     * get fold
     */
    public function getfold()
    {
        return $this["fold"];
    }
    /**
     * set fold
     */
    public function setfold($v)
    {
        $this["fold"] = $v;
        return $this;
    }
    /**
     * get dx
     */
    public function getdx()
    {
        return $this["dx"];
    }
    /**
     * set dx
     */
    public function setdx($v)
    {
        $this["dx"] = $v;
        return $this;
    }
    /**
     * get dy
     */
    public function getdy()
    {
        return $this["dy"];
    }
    /**
     * set dy
     */
    public function setdy($v)
    {
        $this["dy"] = $v;
        return $this;
    }

    protected function initialize()
    {
        $this->math = "0";
        $this->shadow = "0";
        $this->pageScale = 1;
        $this->page = 1;
        $this->fold = 1;
        $this->connect = 1;
        $this->tooltips = 1;
        $this->guides = 1;
        $this->grid = 1;
        $this->gridSize = 10;
        $this->dx = 297;
        $this->dy = 382;
        $this->m_root = new root();
        parent::add($this->m_root);
    }
    public function setMath($v)
    {
        $this["math"] = $v;
        return $this;
    }
    public function getMath()
    {
        return $this["math"];
    }
    public function setPageScale($v)
    {
        $this["pageScale"] = $v;
        return $this;
    }
    public function getPageScale()
    {
        return $this["pageScale"];
    }

    /**
     * get pageHeight
     */
    public function getPageHeight()
    {
        return $this["pageHeight"];
    }
    /**
     * set pageHeight
     */
    public function setPageHeight($v)
    {
        $this["pageHeight"] = $v;
        return $this;
    }
    /**
     * get PageWidth
     */
    public function getPageWidth()
    {
        return $this["pageWidth"];
    }
    /**
     * set PageWidth
     */
    public function setPageWidth($v)
    {
        $this["pageWidth"] = $v;
        return $this;
    }

    protected function _Add($node, $index = null)
    {
        if ($node === $this->m_root) {
            return parent::_Add($node, $index);
        }
        return $this->m_root->add($node, $index);
    }
}
