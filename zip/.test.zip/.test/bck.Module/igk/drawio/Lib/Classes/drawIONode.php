<?php
// @author: C.A.D. BONDJE DOUE
// @filename: drawIONode.php
// @date: 20220503 19:37:47
// @desc: 

namespace igk\drawio; 

use igk\drawio\Styles\mxStyleProperty;
use IGK\System\Html\XML\XmlNode;

abstract class drawIONode extends XMLNode{
 

    protected $styletype;

    const METRIX_ATTRIBS = "parent|as|vertex";


    public function __construct(){
        parent::__construct(basename(igk_uri(static::class)));
        $this->initialize();        
    }
    protected function initialize(){
        // initialize node      
        $this["style"] = new mxStyleProperty($this->styletype);
    }
    public function setContent($value)
    {
        if (is_string($value)){
            $this["value"] = $value;
        }
        return $this;
    }
    public static function CreateWebNode($n, $attributes = null, $indexOrargs = null)
    {
        if (class_exists($cl = __NAMESPACE__."\\".$n)){
            $g = new $cl();
            if (!is_null($attributes)){
                $g->setAttributes($attributes);
            }
            return $g;
        }
        return parent::CreateWebNode($n, $attributes, $indexOrargs);
    }
}