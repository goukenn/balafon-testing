<?php

// @author: C.A.D. BONDJE DOUE
// @filename: mxGraphModel.php
// @date: 20220503 19:38:28
// @desc: 

namespace igk\drawio;

use IGK\System\Html\Dom\HtmlCallbackNode;
use IGK\System\Html\Dom\HtmlCallbackValueAttribute;

class mxCell extends identifiableDrawIONode{
    protected $styletype = "";

    protected function initialize()
    {
        $this["id"] = self::GetIdCounter();
        parent::initialize();
    }
    public function setParent(?identifiableDrawIONode $parent=null){
        if (is_null($parent)){
            $this["parent"] = null;
            return $this;
        }
        $this["parent"] = new HtmlCallbackValueAttribute(function()use($parent){          
            return  $parent["id"];
        }, $parent);
        return $this;
    }
    public function getParent(){
        if ($p = $this["parent"]){
            if ($p instanceof HtmlCallbackValueAttribute){
                return $p->options;
            }
        }
        return null;
    }
    /**
     * 
     * @param mixed $properties 
     * @return void 
     */
    public function setStyle($properties){
        if (is_array($properties)){
            array_map(function($v, $k){
                $this["style"][$k] = $v;                 
             }, $properties, array_keys($properties));
        }
        return $this;
    }
}
