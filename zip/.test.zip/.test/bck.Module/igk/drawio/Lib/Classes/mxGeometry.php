<?php

// @author: C.A.D. BONDJE DOUE
// @filename: mxGraphModel.php
// @date: 20220503 19:38:28
// @desc: 

namespace igk\drawio;

class mxGeometry extends drawIONode{
    static $DefaultGeoMetry = [
        "x"=>0,
        "y"=>0,
        "width"=>200,
        "height"=>200,
        "as"=>"geometry", 
    ];
}
