<?php

// @author: C.A.D. BONDJE DOUE
// @filename: mxGraphModel.php
// @date: 20220503 19:38:28
// @desc: 

namespace igk\drawio;

class root extends drawIONode{
    
}
