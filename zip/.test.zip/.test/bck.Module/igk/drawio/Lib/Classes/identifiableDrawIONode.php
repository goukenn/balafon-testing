<?php
// @author: C.A.D. BONDJE DOUE
// @filename: drawIONode.php
// @date: 20220503 19:37:47
// @desc: 

namespace igk\drawio; 

use igk\drawio\Styles\mxStyleProperty;
use IGK\System\Html\XML\XmlNode;

abstract class identifiableDrawIONode extends drawIONode{
    protected static $idCounter = 0;

    public static function GetIdCounter(){        
        return "".self::$idCounter++;
    }

}