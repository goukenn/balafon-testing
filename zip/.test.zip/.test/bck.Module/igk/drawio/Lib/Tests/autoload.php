<?php
// @author: C.A.D. BONDJE DOUE
// @date: 20220503 19:36:07

require_once $_ENV["IGK_APP_DIR"]."/Lib/igk/Lib/Tests/autoload.php";
