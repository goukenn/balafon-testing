<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/drawio/.global.php
// @date: 20220503 19:36:07

// + module entry file 
