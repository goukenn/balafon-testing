<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igkservices/.global.php
// @date: 20230123 17:00:19

// + module entry file 
