# igk/estock

Module that help to manage your stocks 

@C.A.D.BONDJEDOUE