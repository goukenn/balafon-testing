<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/estock/.global.php
// @date: 20230315 11:02:20

// + module entry file 
