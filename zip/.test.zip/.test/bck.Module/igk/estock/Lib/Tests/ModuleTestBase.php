<?php
// @author: C.A.D. BONDJE DOUE
// @date: 20230315 11:02:20
namespace igk\estock\Tests;

use IGK\Tests\BaseTestCase;

///<summary></summary>
/**
* 
* @package igk\estock\Tests
*/
abstract class ModuleTestBase extends BaseTestCase{
	public static function setUpBeforeClass(): void{
	   igk_require_module(__NAMESPACE__);
	}
}