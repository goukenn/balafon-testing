# igk\Markdown module 

- require 
composer package Parsdown : erusev/pardown

- Author @bondje.doue@igkdev.com

Balafon markdown module that help to create and edit markdown document. 


- added global function 

## igk_html_node_markdown_document() : create a markdown document

## markdown_convert_md_to_html($node, $content): load markdown content to node

```php
markdown_convert_md_to_html($n = igk_create_node('div'), $content) ? $n->render() : null;
```