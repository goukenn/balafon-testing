<?php
// @file: .global.php
// @author: C.A.D. BONDJE DOUE
// @description: 
// @copyright: igkdev © 2019
// @license: Microsoft MIT License. For more information read license.txt
// @company: IGKDEV
// @mail: bondje.doue@igkdev.com
// @url: https://www.igkdev.com
// @required : composer package erusev/pardown
// @package uri: https://packagist.org/packages/erusev/parsedown
///<summary>convert md file to html expression </summary>

use igk\Markdown\MarkdownDocument;

if (!function_exists('markdown_convert_md_to_html')){
function markdown_convert_md_to_html($d, $content, bool $secure=true){
    if (!class_exists($cl = \Parsedown::class)){
        if (igk_environment()->isDev()){
            igk_die("Parsedown::class from composer is missing");
        }
        return false;
    }
    $p = new $cl;
    $p->setSafeMode($secure);
    return $d->Load($p->text($content));       
}
}

/**
 * dummry markdown document
 * @return MarkdownDocument 
 */
function igk_html_node_markdown_document(){
 
   return new MarkdownDocument();    
}