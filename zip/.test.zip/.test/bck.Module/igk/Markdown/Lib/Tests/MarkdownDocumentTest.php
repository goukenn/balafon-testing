<?php
 
// @author: C.A.D. BONDJE DOUE
// @filename: MarkdownDocumentTest.php
// @date: 20220730 23:54:20
// @desc: 


namespace igk\Markdown\Tests;

use \igk\Markdown\MarkdownDocument;
use IGK\Tests\BaseTestCase;


// > phpunit -c phpunit.xml.dist ./src/application/Packages/Modules/igk/markdown/Lib/Tests/MarkdownDocumentTest.php

class MarkdownDocumentTest extends BaseTestCase{
    public function setUp():void{
        igk_include_module(\igk\Markdown::class);
    }
    public function test_markdown_document(){
        $doc = new MarkdownDocument;
        $doc->h1()->Content = "Hi, Friend";
        $doc->h2()->Content = "Hi, Friend 2";
        // $doc->h1()->Content = "Hi, Friend";
        // $doc->h1()->Content = "Hi, Friend";
        // $doc->h1()->Content = "Hi, Friend";

        $this->assertEquals(
            "# Hi, Friend\n## Hi, Friend 2",
            $doc->render_output(),
            "Markdown document not render perfectly"
        );
    }
    public function test_sup_script(){
        $doc = new MarkdownDocument;
        $doc->superscript()->Content = "X<sup>2</sup>";

        $this->assertEquals(
            "X^2^",
            $doc->render_output(),
            "Markdown document not render perfectly"
        );
    }
    public function test_sub_script(){
        $doc = new MarkdownDocument;
        $doc->superscript()->Content = "H<sub>2</sub>O";

        $this->assertEquals(
            "H~2~O",
            $doc->render_output(),
            "Markdown document not render perfectly"
        );
    }
    public function test_highlight_script(){
        $doc = new MarkdownDocument;
        $doc->superscript()->Content = "My <highlight>important word</highlight>";

        $this->assertEquals(
            "My ==important word==",
            $doc->render_output(),
            "Markdown document not render perfectly"
        );
    }

    public function test_emoji_script(){
        $doc = new MarkdownDocument;
        $doc->div()->Content = "My :<emoji>joy</emoji>";

        $this->assertEquals(
            "My ::joy:",
            $doc->render_output(),
            "Markdown document not render perfectly"
        );
    }
    public function test_strike_script(){
        $doc = new MarkdownDocument;
        $doc->div()->Content = "My :<strike>joy</strike";
        $this->assertEquals(
            "My :~~joy~~",
            $doc->render_output(),
            "Markdown document not render perfectly"
        );
    }
    public function test_footref_script(){
        $doc = new MarkdownDocument;
        $doc->div()->Content = "My :<footref>1</footref";
        $this->assertEquals(
            "My :[^1]",
            $doc->render_output(),
            "Markdown document not render perfectly"
        );
    }
    public function test_footnote_script(){
        $doc = new MarkdownDocument;
        $doc->div()->Content = "<footnote>1</footnote>presentation";
        $this->assertEquals(
            "[^1]: presentation",
            $doc->render_output(),
            "Markdown document not render perfectly"
        );
    }

    public function test_with_refid_script(){
        $doc = new MarkdownDocument;
        $doc->h1()->Content = "Present <refId>home</refId>";
        $this->assertEquals(
            "# Present {#home}",
            $doc->render_output(),
            "Markdown document not render perfectly"
        );
    }

    public function test_blockquote(){
        $doc = new MarkdownDocument;
        $doc->blockquote()->Content = implode("\n", ["One <sub>f</sub>", "Line"]);
        $this->assertEquals(
            "> ".implode("\n> ", ["One ~f~", "Line"]),
            $doc->render_output(),
            "Markdown document not render perfectly"
        );
    }
}
