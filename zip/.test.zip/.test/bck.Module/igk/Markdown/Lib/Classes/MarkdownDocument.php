<?php

namespace igk\Markdown;

use Exception;
use \HtmlNode;
use IGK\System\Exceptions\CssParserException;
use IGK\System\Html\HtmlRenderer;
use IGKException;
use ReflectionClass;

/**
 * 
 * @package igk\Markdown
 * use render_output to render generated document
 */
class MarkdownDocument  extends MarkdownNode{
    protected $html_tagname = "div";
    public function __construct(){ 
        parent::__construct("markdown-document");
    }
    /**
     * render output document - engine
     * @param int $output 
     * @param mixed $engine 
     * @return string 
     * @throws IGKException 
     * @throws Exception 
     * @throws CssParserException 
     */
    public function render_output($output=1, $engine=null){
        $s = "";
        $options =  igk_createobj([
            "Engine" => $engine ?? new MarkdownEngine(igk_app()->getDoc()->Theme)
        ]);
        ob_start();
        $s .= HtmlRenderer::Render($this, $options);       
        if($output){
            echo $s;
        }
        ob_end_clean();
        return $s;
    }

   
}