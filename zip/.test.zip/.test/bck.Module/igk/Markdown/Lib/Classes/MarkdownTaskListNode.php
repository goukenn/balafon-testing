<?php

namespace igk\Markdown;


class MarkdownTaskListNode extends MarkdownNode{   

    public function __construct(){
        parent::__construct("markdown-task-list"); 
    }
}