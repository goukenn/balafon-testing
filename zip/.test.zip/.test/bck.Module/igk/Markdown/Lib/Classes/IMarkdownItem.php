<?php
namespace igk\Markdown; 

/**
 * 
 * @package igk\Markdown
 * @method  emoji() add emoji item
 * @method  sub() add emoji item
 * @method  sup() add sup item
 * @method  strike() strike item
 * @method  footref() add foot not reference
 * @method  footnote() add define foot not 
 * @method  refId() add define a reference Id
 */
interface IMarkdownItem{

}