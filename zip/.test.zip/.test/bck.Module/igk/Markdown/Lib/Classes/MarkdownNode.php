<?php

// @author: C.A.D. BONDJE DOUE
// @filename: MarkdownNode.php
// @date: 20220730 23:26:49
// @desc: markdown default node

namespace igk\Markdown; 
use IGK\System\Html\Dom\HtmlNode;
use ReflectionClass;

/**
 * 
 * @package igk\Markdown
 * 
 */
abstract class MarkdownNode  extends HtmlNode implements IMarkdownItem{

    protected $html_tagname;

    protected static function _GetTagName($node)
    {
        if ($node instanceof MarkdownNode) {
            if (!empty($c = $node->html_tagname)) {
                return $c;
            }
        }
        return $node->getTagName();
    }
    public function isCloseTag($n){
        $t = self::_GetTagName($this);
        return $n == $t;
    }
    public function __construct($tagname=null){
        if ($tagname==null){
            $tagname = "markdown-".str_replace("\\", "-", strtolower(static::class));
        }
        parent::__construct($tagname);
    }

    public function getIsLitteralContent(){
        return true;
    }

    public static function CreateWebNode($name, $attributes = null, $indexOrArgs = null)
    {
        
        if (class_exists($cl = __NAMESPACE__."\\Markdown".ucfirst($name)."Node") && !(igk_sys_reflect_class($cl))->isAbstract()){
            if ($indexOrArgs==null){
                $indexOrArgs = [];
            }
            $o = new $cl(...$indexOrArgs);
            if ($attributes)
            $o->setAttribute($attributes); 
            return $o;
        }        
        $o = HtmlNode::CreateWebNode($name, $attributes, $indexOrArgs);
        $o->setTempFlag("RootNS", [static::class, __FUNCTION__]);
        return $o;
    }
}