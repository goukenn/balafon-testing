<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/social/facebook/global.php
// @date: 20220106 16:27:25

// + module entry file 
// 

use IGK\Helper\SysUtils;
use IGK\System\Html\Dom\HtmlNode; 
use igk\social\facebook\GraphEndPoints;
use IGK\System\Html\HtmlUtils;
use IGK\System\Services\SignProvider;

use function igk_resources_gets as __;

function igk_html_node_facebook_login_button(?array $options=null){
    $n = new HtmlNode("div");
    $n->setAttributes([
        "class"=>"facebook-container fb-login-button",
    ]); 
    $client_id = "";
    $redirect_uri = "";
    $state = "";
    $scope="public_profile,email";
    $auth_type=""; 
    $module = SysUtils::GetApplicationModule(__FILE__);
    if ($options){
        extract($options, EXTR_OVERWRITE);
    } else {
        // + | bind config status
        $cnf = igk_configs();
        $client_id = $cnf->get("facebook.app_client_id");
        $scope = $cnf->get("facebook.scope", $scope);
        $redirect_uri = SignProvider::GetRedirectUri() ?? $cnf->get("facebook.redirect_uri");
        $state = base64_encode(json_encode(["cref"=>igk_app()->getSession()->getCref(), "SESS_ID"=>session_id()])); // $cnf->get("facebook.app_client_id");
    } 
    // append provider to redirect uri  
    $q = HtmlUtils::AppendQueryArgs($redirect_uri, ["provider"=>GraphEndPoints::ProviderName]);
    $redirect_uri = explode("?", $redirect_uri)[0]."?".http_build_query($q);
    $query = http_build_query(compact("client_id", "redirect_uri", "state", "scope", "auth_type"));
    $a = $n->a(GraphEndPoints::Login. "?".$query); 
    $tr = $a->table()->tr();
    $tr->td()->img("https://static.xx.fbcdn.net/rsrc.php/v3/yN/r/szGrb_tkxMW.png");
    $tr->td()->text(__("Login with Facebook"));
    FBInitNode::true();
    return $n;
}


function igk_html_node_facebookOAuthLink($data){
	$n = igk_create_node("a");
	$q = igk_array_filter($data, ["scope"=>0, "auto-logout-link"=>0, "layout"=>1, "size"=>1, "button-type"=>1,"use-continue-as"=>0]); 
	$n["class"]="fb-login-button";
	foreach($q as $k=>$v){
		$n["data-".$k] = $v;
	} 
	return $n;
}

function fb_initAnalytics($t, $appId, $version, $redirectUri=null){
 $js_invoke ="";
 if ($redirectUri){
	    $js_invoke = <<<EOF
igk.ajx.postFormData("{$redirectUri}", {
   'facebookrep':response.authResponse
});
EOF;
}
	$t->addNoTagObData(function()use($appId, $version,  $js_invoke){
		?>		
<script type="text/javascript" language="javascript"> 
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '<?= $appId ?>',
      cookie     : true,
      xfbml      : true,
      version    : '<?= $version ?>'
    });      
    FB.AppEvents.logPageView();   
	 
   // get login status
   FB.getLoginStatus(function(response) {  
	   if (response.status == "connected"){	
		   <?=  $js_invoke ?> 
		   return;
	   } 
	   // statusChangeCallback(response);
	}); 
  
	//call login directory
	// FB.login(function(response){
		// console.debug("login page");
	// });
	FB.Event.subscribe('auth.login', function(response){
	 
		if (response.status == "connected"){	
		   <?=  $js_invoke ?> 
		   return;
	   }  
	});
  };
  
 
  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "https://connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs); 
   }(document, 'script', 'facebook-jssdk'));
 
</script><?php
	}); 
}