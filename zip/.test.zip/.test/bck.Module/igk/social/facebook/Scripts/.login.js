(function(appid, appversion, lang, app_redirect_uri) {

    let coreStatus = null;
    window.fbAsyncInit = function() {
        FB.init({
            appId: appid,
            cookie: true,
            xfbml: true,
            version: appversion
        });
        FB.AppEvents.logPageView();
        // connection loading proces no need to check fb login status
        FB.getLoginStatus(function(response) {
            if (response.status == 'connected') {
                // change the button type to be continue with
                $igk('fb:login-button').each_all(function() {
                    this.setAttribute("data-button-type", "continue_with");
                    this.on("click", function(e) {
                        e.preventDefault();
                        e.stopPropagation();
                        alert("click on the button");
                    });
                });
                FB.logout();
                coreStatus = response;
            }
        });
    };
    (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) { return; }
        js = d.createElement(s);
        js.id = id;
        js.src = "https://connect.facebook.net/" + lang + "/sdk.js";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));

    let _NS = igk.system.createNS('igk.extern.social.faceBook', {
        statusChangeCallback(response) {
            if (response.status == 'connected') {
                igk.ajx.post({
                    "uri": app_redirect_uri,
                    "contentType": "application/json",
                }, JSON.stringify(response.authResponse), function(xhr) {
                    if (this.isReady()) {
                        if (xhr.responseText) {
                            let cp = JSON.parse(xhr.responseText);
                            if (cp.status == 'OK') {
                                document.location = cp.redirectURL;
                            }
                        }
                    }
                });
            }
        },
        checkLoginState() {
            FB.getLoginStatus(_NS.statusChangeCallback);
        }
    });
})