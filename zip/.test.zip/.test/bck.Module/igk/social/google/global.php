<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/social/google/global.php
// @date: 20220107 11:36:33

// + module entry file 

use IGK\System\Html\Dom\HtmlNode;

/**
 * creaate google login button
 * @return HtmlNode 
 */
function igk_html_node_google_login_button(){
    // configuration du bouton à utiliser si 
    $dv = new HtmlNode("div");
    $dv->setAttributes([
        "class"=>"g_id_signin dispib",  
        "data-type"=>"standard",
        "data-shape"=>"rectangular",
        "data-theme"=>"outline",
        "data-text"=>"signin_with",
        "data-size"=>"large",
        "data-logo_alignment"=>"left"
    ]);    
    return $dv;
}