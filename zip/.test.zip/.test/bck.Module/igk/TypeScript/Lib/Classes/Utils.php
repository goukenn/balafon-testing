<?php

namespace igk\TypeScript;

use \ReflectionClass;
use \igk\js\Angular\TypeScriptBuilder;

class Utils
{

    public static function GetInterfaceDefinition($cl, $data=[])
    {
        
        return \igk_ob_get_func(function () use ($cl, $data) {

            //+ | get Peperties Interface Class  ==> type script  
            $ref = igk_sys_reflect_class($cl);
            $s = "";
            $tab = $ref->getProperties();
            usort($tab, function ($a, $b) {
                return strcmp($a->getName(), $b->getName());
            });
            $c = 0;
            foreach ($tab as $m) {
                if ($m->isStatic() || $m->isPrivate())
                    continue;
                if ($c) {
                    $s .= "\n";
                }
              
                $s .=  $m->getName() . "?: any;";
                $c = 1;
            }
            $builder = new TypeScriptBuilder();

            $builder->type("interface")
                ->name(basename(igk_uri($ref->getName())))
                ->export(true)
                ->definition($s);
            echo "// @builder: \n";
            echo "// @author: ".igk_get_env("script_author", IGK_AUTHOR)."\n";
            echo "// @date: ".date("Ymd H:i:s")."\n";
            echo "// @description:".igk_getv($data, "description"). "\n"; 
            echo "// generate typescript interface \n";
            echo $builder->render();
        });
    }
}
