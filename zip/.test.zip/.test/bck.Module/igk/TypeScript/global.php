<?php
// @author: C.A.D. BONDJE DOUE
// @file: %packages%/Modules/igk/TypeScript/global.php
// @desc: 
// @date: 20210902 01:19:21

// + module entry file 

