<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/ecommerce/.global.php
// @date: 20230205 07:47:04

// + module entry file 
