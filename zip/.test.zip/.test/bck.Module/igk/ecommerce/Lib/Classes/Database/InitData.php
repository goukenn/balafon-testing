<?php
namespace igk\ecommerce\Database;

use IGK\Controllers\BaseController;
use IGK\System\Database\InitBase;

class InitData extends InitBase{
    var $product_model;
    var $product_type_model;
    var $product_unit_model;
    var $cart_model;
    var $unit_types;
    var $product_types;
    public function initialize(){
        if ($cl = $this->unit_types){
            $cl::InitData();
        }
        if ($cl = $this->product_types){
            $cl::InitData();
        }
    }
    public static function Init(BaseController $controller){

    }
}