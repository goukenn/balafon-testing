<?php
// @author: C.A.D. BONDJE DOUE
// @filename: ECommerceControllerServiceTrait.php
// @date: 20230205 08:48:49
// @desc: 


trait ECommerceControllerServiceTrait{
    
}