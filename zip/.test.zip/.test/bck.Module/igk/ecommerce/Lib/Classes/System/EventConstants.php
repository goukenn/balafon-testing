<?php

// @author: C.A.D. BONDJE DOUE
// @filename: EventConstants.php
// @date: 20230210 07:49:20
// @desc: payement event hook

namespace igk\ecommerce\System;

abstract class EventConstant{
    const ECOM_KEY = "ecom://hook";
    const HOOK_ECOM_PRODUCT_ADD = self::ECOM_KEY."/product_added";
    const HOOK_ECOM_PRODUCT_REMOVE = self::ECOM_KEY."/product_removeddded";
    const HOOK_ECOM_PRODUCT_UPDATE = self::ECOM_KEY."/product_update";
    const HOOK_ECOM_CART_ITEM_ADD = self::ECOM_KEY."/cart_item_added";
    const HOOK_ECOM_CART_ITEM_REMOVE = self::ECOM_KEY."/cart_item_remove";
    const HOOK_ECOM_CART_ITEM_CLEAR = self::ECOM_KEY."/cart_item_clear";
}
