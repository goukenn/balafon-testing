<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/webpack/.global.php
// @date: 20220828 14:52:13

// + module entry file 
