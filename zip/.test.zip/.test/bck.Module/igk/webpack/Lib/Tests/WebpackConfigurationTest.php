<?php

// @author: C.A.D. BONDJE DOUE
// @filename: WebpackConfigurationTest.php
// @date: 20221130 22:44:27
// @desc: 

namespace igk\webpack\Tests;

use IGK\Tests\BaseTestCase;
use igk\webpack\System\IO\WebpackConfig;
use igk\webpack\System\IO\WebpackConfigBuilder;

class WebpackConfigurationTest extends BaseTestCase{
    public static function setUpBeforeClass(): void
    {
       $module = igk_get_current_module_name(__DIR__);  
       $mod = igk_require_module($module);
       // $mod->register_autoload();
    }
    public function test_new_configuration(){

        $builder = new WebpackConfigBuilder;
        $this->assertEquals(
            implode("\n", [
                'module.exports = {',
                '};', 
                ''               
            ]),
            $builder->render()
        );
    }

    public function test_new_configuration_o(){

        $builder = new WebpackConfigBuilder;
        $config = new WebpackConfig;
        $config->output = "/dist";
        $builder->addConfig($config);
        $this->assertEquals(
            implode("\n", [
                'module.exports = {',
                '};', 
                ''               
            ]),
            $builder->render()
        );
    }
}
