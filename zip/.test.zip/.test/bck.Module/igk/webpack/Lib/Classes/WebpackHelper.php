<?php
// @author: C.A.D. BONDJE DOUE
// @filename: WebpackHelper.php
// @date: 20220828 15:07:51
// @desc: pack helper

namespace igk\webpack;

use Closure;
use IGK\Helper\IO;
use IGK\System\IO\Path;
use IGKException;

/**
 * 
 * @package igk\webpack
 */
class WebpackHelper
{
    private $_output;
    private $_files;

    private function __construct()
    {
        $this->_output = "";
    }
    private function _resolvFile($f)
    {
        $ext = Path::GetExtension($f);
        $F = igk_io_collapse_path($f);
        $s = &$this->_output;
        switch (($ext)) {
            case ".js";
                $s .= IGK_START_COMMENT . "F: " . $F . "" . IGK_END_COMMENT . IGK_LF;
                $s .= file_get_contents($f);
                break;
            default:
                //resolv to asset folder
                break;
        }
        $this->_files[] = $f;
    }
    public static function GetScriptSources($dirs, &$files = []): string
    {

        $helper = new self;
        $resolverfc = Closure::fromCallable([$helper, '_resolvFile']);
        $helper->_files = &$files;

        // function ($f) use (&$s) {
        //     $ext = Path::GetExtension($f);
        //     $F = igk_io_collapse_path($f);
        //     switch (($ext)) {
        //         case ".js";
        //             $s.= IGK_START_COMMENT."F: ". $F."".IGK_END_COMMENT.IGK_LF;
        //             $s .= file_get_contents($f);
        //             break;
        //         default:
        //             //resolv to asset folder
        //             break;
        //     }
        // };

        IO::GetFiles($dirs, "/\.(js|json|xml|svg|shader|txt|img|png|jpg|fs|vh)$/", true, $exclude_dir, $resolverfc);
        return $helper->_output;
    }

    /**
     * check npm or die
     * @return array 
     * @throws IGKException 
     */
    public static function CheckNpm(){
        $node_dir = "node_modules";
        $npm_temp = `npm config get tmp`;

        if (!is_dir($g = trim($npm_temp) . "/" . $node_dir)) {
            IO::CreateDir($g) || igk_die("cant create npm tempory directory");
            unset($g);
        }
        $cache_dir = trim(`npm config get cache`);
        if (!is_dir($cache_dir)) {
            IO::CreateDir($cache_dir) || igk_die("can't create npm cache directory");
        }
        return compact('npm_temp', 'cache_dir');
    }
}
