<?php

namespace igk\webpack;

use IGK\Css\ICssResourceResolver;
use IGK\Helper\IO;
use IGKResourceUriResolver;

class WebpackResourceResolver implements ICssResourceResolver
{
    public $outputDir;
    public $entryUri = './assets/';
    /**
     * store file and uri to resolv
     * @var array
     */
    public $files = [];
    /**
     * store application extra script path
     * @var array
     */
    public $appScripts = [];

    public function resolveColor(string $keyValue): ?string {
        return null;
    }
    public function resolve(string $path): ?string
    { 

        if (is_file($path)) {
            
            $rp = realpath($path);
            if (isset($this->files[$rp])){
                return $this->files[$rp];
            }
            // igk_wln_e("reol ".$path);
            $g = IGKResourceUriResolver::getInstance()->resolveOnly($path);
            $g = igk_str_rm_start($g, "../");
            if (explode("/", $g)[0] == IGK_RES_FOLDER) {
                $g = igk_str_rm_start($g, IGK_RES_FOLDER . "/");
            }
            $ln = implode("/", [rtrim($this->outputDir, "/"), ltrim($g, "/")]);
            IO::CreateDir(dirname($ln));
            @symlink($path, $ln);           
            $f = $this->entryUri . $g;
            WebPackLog::Log("\nresource resolver : " . $g . "=>".$f);
            $this->files[$rp] = $f;
            return $f;
        }

    }
}
