<?php

// @author: C.A.D. BONDJE DOUE
// @filename: WebpackManifestRule.php
// @date: 20220828 15:00:38
// @desc: 

namespace igk\webpack;

use igk\js\common\JSExpression;


class WebpackManifestRule // implements //IJSStringify
{
    /**
     * for testing
     * @var mixed
     */
    var $test;

    /**
     * ressource types
     * @var mixed
     */
    var $type;

    /**
     * 
     * @var ?WebpackGeneratorInfo
     */
    var $generator;
    /**
     * use loader
     * @var ?array list of used loader
     */
    var $use;
    const ASSET_RES = "asset/resource";
    const ASSET = "asset";   
    /**
     * create asset rule
     * @param string $jsregex 
     * @return WebpackManifestRule 
     * @throws IGKException 
     */
    public static function createAssetRule(string $jsregex, ?WebpackGeneratorInfo $generatorInfo=null){
        $n = new self;
        $n->test = JSExpression::Create(":".$jsregex);
        $n->type = self::ASSET_RES;
        $n->generator = $generatorInfo;
        return $n;
    }
}
