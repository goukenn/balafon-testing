<?php

// @author: C.A.D. BONDJE DOUE
// @filename: WebpackGeneratorInfo.php
// @date: 20220828 15:01:06
// @desc: 


namespace igk\webpack;
/**
 * webpack generator info
 * @package igk\webpack
 */
class WebpackGeneratorInfo{
    var $filename;
    var $emit;
    var $dataUrl;
    var $publicPath;
    var $outputPath;
}

