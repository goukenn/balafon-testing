<?php
// @author: C.A.D. BONDJE DOUE
// @filename: WebpackCompiler.php
// @date: 20220828 15:10:41
// @desc: 

namespace igk\webpack;


use IGK\Helper\FileBuilderHelper;
use IGKException;
use IGK\System\Exceptions\ArgumentTypeNotValidException;
use ReflectionException;

/**
 * 
 * @package igk\webpack
 */
class WebpackCompiler
{
    var $outputDir;
    var $resolver;
    var $data;
    var $controller;
    var $document;

    /**
     * default distribution name
     * @var mixed
     */
    var $distName = "dist";

    var $assets = [];

    var $allowHiddenFile = false;

    public function addAssets($file){
        $this->assets[] = $file;
        return $this;
    }

    /**
     * build with webpack
     * @return void 
     * @throws IGKException 
     * @throws ArgumentTypeNotValidException 
     * @throws ReflectionException 
     */
    public function build()
    {
        if (empty($this->data)){
            igk_die("data must be set");
        }
        if (!($fc = igk_getv($this->data, "webpack.config.js"))  || !is_callable($fc)){
            igk_die("webpack.config.js is missing definition");
        }  
        
        FileBuilderHelper::Build($this->data, true, $this);
    }
}
