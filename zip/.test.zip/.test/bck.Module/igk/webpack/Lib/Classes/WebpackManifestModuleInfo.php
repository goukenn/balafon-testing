<?php

// @author: C.A.D. BONDJE DOUE
// @filename: WebpackManifestModuleInfo.php
// @date: 20220828 14:56:52
// @desc: 

namespace igk\webpack;


class WebpackManifestModuleInfo
{
    /**
     * return to attache 
     * @var mixed
     */
    var $rules;

    /**
     * 
     * @param mixed $rule 
     * @return void 
     */
    public function addRule($rule)
    {
        if (!$this->rules) {
            $this->rules = [];
        }
        $this->rules[] = $rule;
        return $this;
    }
}

