<?php

// @author: C.A.D. BONDJE DOUE
// @filename: WebpackManifestInfo.php
// @date: 20220828 15:13:01
// @desc: 

namespace igk\webpack;


class WebpackManifestInfo
{
    /**
     * entry list to build
     * @var string|string[]
     */
    var $entry;

    /**
     * mode of manifest
     * @var string development|production
     */
    var $mode;

    /**
     * 
     * @var mixed
     */
    var $output;

    /**
     * list of plugins to imports
     * @var string[]
     */
    var $plugins;

    /**
     * array of modules
     * @var array
     */
    var $module;

    /**
     * clean data
     * @var bool
     */
    var $clean;

    public function __set($n, $v)
    {
        die(__("not allowed property {%s}.", $n));
    }
    public function addRule($rule)
    {
        if (!$this->module) {
            $this->module = new WebpackManifestModuleInfo();
        }
        $this->module->addRule($rule);
        return $this;
    }
}



