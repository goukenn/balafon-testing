<?php

// @author: C.A.D. BONDJE DOUE
// @filename: WebPackLog.php
// @date: 20220828 15:08:34
// @desc: 


namespace igk\webpack;


class WebPackLog
{
    static $msg = [];
    public static function Log($msg)
    {
        self::$msg[] = $msg;
    }
}

