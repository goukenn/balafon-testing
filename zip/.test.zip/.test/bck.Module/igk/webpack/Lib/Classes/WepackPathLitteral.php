<?php

// @author: C.A.D. BONDJE DOUE
// @filename: WepackPathLitteral.php
// @date: 20220828 14:56:52
// @desc: litteral use in path composition

namespace igk\webpack;

/**
 * litteral use in path composition
 * @package igk\webpack
 */
class WepackPathLitteral{
    const HASH = "[hash]";
    const EXT = "[ext]";
    const QUERY = "[query]";
    const PATH = "[path]";
    const FILE = "[file]";
    const NAME = "[name]";
    const BASE = "[base]";
    const FRAGMENT = "[fragment]";
}


