<?php

namespace igk\devtools;
 
use IGK\System\Console\Logger;
use IGK\System\IO\Path;
use IGK\System\Uri;
use IGK\System\Html\IO\ImageLoader as coreImageLoader;

class ImageLoader extends  coreImageLoader{
 
}