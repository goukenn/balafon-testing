<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/devtools/.global.php
// @date: 20221205 15:12:10

// + module entry file 
