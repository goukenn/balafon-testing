<?php
// @author: C.A.D. BONDJE DOUE
// @filename: autoload.php
// @date: 20230315 08:20:28
// @desc: 

// register some class 


igk_wln_e("lkdjfs");