<?php


namespace igk\bootstrap;


class DataBSToggle{
    const offcanvas = "offcanvas";
    const toggle = "toggle";
    const bootstrap_attributes = "data-bs-toggle|data-bs-target|data-bs-parent";
}