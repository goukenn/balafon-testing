<?php
// Use of global api 
require_once(__DIR__."/Lib/Classes/Service.php");

IGKServices::Register("ovh", \igk\ovh\Service::class); 

