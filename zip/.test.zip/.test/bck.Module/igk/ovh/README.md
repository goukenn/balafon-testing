# Balafon Modules igk\OVH

## requirement

- composer package : ovh/ovh

```
composer require ovh/ovh
```
- register mail

```PHP
$cnf = $ctrl->getConfigs();
$credential = ApiCredential::Create([
    "ApiKey" => $cnf->get("ovh.ApiKey"),
    "ApiSecret" => $cnf->get("ovh.ApiSecret"),
    "ConsumerKey" => $cnf->get("ovh.ConsumerKey"),
    "EndPoint" => $cnf->get("ovh.EndPoint"),
]);
$ovh_mail = new \igk\ovh\Models\Emails($credential);

$d= $ovh_mail->getDomains(); 
```


# Server Configuration 

> User : compte mail créer sur le serveur 
> PWD : le mot de passe du compte
> Server : ssl://ssl0.ovh.net
> Port : 465
> Type : ssl

# accéder à la boite generique
https://webmail.mail.ovh.net 

- attention le champ contactTo et utilisateur doivent être identique pour l'envoie de mail.