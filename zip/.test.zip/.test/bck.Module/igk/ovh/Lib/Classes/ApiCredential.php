<?php

namespace igk\ovh;

///<summary>represent credential uses</summary>
class ApiCredential{
    var $ApiKey;
    var $ApiSecret;
    var $ConsumerKey;
    var $EndPoint;

    private function __construct(){
    }
    public static function Create($data){
        if (empty($data))
            return null;
        $c = new self();
        $properties = igk_relection_get_properties_keys(__CLASS__); 
        foreach($data as $k=>$v){
            if (key_exists($k = strtolower($k), $properties)){
                $m = $properties[$k]->getName();
                $c->$m = $v;
            }
        }
        return $c;
    }
}