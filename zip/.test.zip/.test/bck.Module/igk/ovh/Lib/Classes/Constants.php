<?php
// @author: C.A.D. BONDJE DOUE
// @filename: Constants.php
// @date: 20221111 09:24:58
// @desc: 

namespace igk\ovh;

abstract class Constants{
    const LOG_TAG = 'ovh-module';
}