<?php

namespace igk\ovh\Models;

use GuzzleHttp\Exception\GuzzleException;
use igk\ovh\ApiCredential;
use JsonException;
use InvalidArgumentException;
use Ovh\Api;
use Ovh\Exceptions\InvalidParameterException;

class Emails{
    private $client;
    public function __construct(ApiCredential $credential){
        if ($credential==null){
            die("argument null");
        }
        $this->setting = $credential;
        $this->client = new Api(
            $this->setting->ApiKey,
            $this->setting->ApiSecret,
            $this->setting->EndPoint,
            $this->setting->ConsumerKey
         );
    }
    public function getServices(){
        return $this->client->get("/email/domain");
    }
    public function getMXServices(){
        return $this->client->get("/email/mxplan");
    }
    public function getMXFree($service){
        return $this->client->get("/email/mxplan/{$service}/account",[
            "primaryEmailAddress"=>"%configureme%"
        ]);
    }
    /**
     * get MX domain account
     * @param string $service 
     * @param string $domain 
     * @return mixed 
     * @throws InvalidParameterException 
     * @throws GuzzleException 
     * @throws JsonException 
     * @throws InvalidArgumentException 
     */
    public function getMXDomainAccount(string $service, string $domain){
        return $this->client->get("/email/mxplan/{$service}/account",[
            "primaryEmailAddress"=>"%{$domain}"
        ]);
    }
    /**
     * change email's password
     * @param string $service 
     * @param string $email 
     * @param string $password 
     * @return mixed 
     * @throws InvalidParameterException 
     * @throws GuzzleException 
     * @throws JsonException 
     * @throws InvalidArgumentException 
     */
    public function MXDomainChangePassword(string $service, string $email, string $password){
        return $this->client->post("/email/mxplan/{$service}/account/{$email}/changePassword",[
            "password"=>$password
        ]);
    }
    /**
     * get all email account
     * @param string $domain 
     * @param array $options accountName
     * @return mixed 
     * @throws InvalidParameterException 
     * @throws GuzzleException 
     * @throws JsonException 
     * @throws InvalidArgumentException 
     */
    public function getEmailAccounts(string $domain, array $options=[]){
        return $this->client->get("/email/domain/{$domain}/account", $options);
    }

    /**
     * 
     * @param string $domain 
     * @param array $options accountName|description|password|size
     * @return mixed 
     * @throws InvalidParameterException 
     * @throws GuzzleException 
     * @throws JsonException 
     * @throws InvalidArgumentException 
     */
    public function createDomainAccount(string $domain, array $options){
        return $this->client->post("/email/domain/{$domain}/account", $options);
    }
    public function getDomainSetting($domain){
        return $this->client->get("/email/domain/{$domain}");
    }
    public function getDomainAccountAllowedSize(string $domain){
        if ($ob = $this->getDomainSetting($domain) ){
            return igk_getv($ob, "allowedAccountSize");
        }
        return -1;
    }
    public function deleteDomainAccount(string $domain, string $account){
        return $this->client->delete("/email/domain/{$domain}/account/{$account}");
    }
    public function getDomains(){
        return $this->client->get('/email/domain');
    }
}