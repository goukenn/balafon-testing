<?php

namespace igk\ovh;


class helper{

    public static function GetEmails($api, $domain) {
        $result = $api->get("/email/domain/".$domain."/account");
        sort($result);
        return $result;
    }
}