<?php

namespace igk\ovh;

use IGK\IService;
use IGK\System\IO\File\IniFile;
use IGK\System\IO\Path;
use IGK\Controllers\ServiceController;

class Service implements IService{
    const SYS_PROPERTY = "ovh.ovhconfig";
    var $enable_firewall;
    private function _initSetting(string $fc){
        $g = IniFile::LoadConfig($fc);
        $this->enable_firewall = (bool) ($g->{"http.firewall"} == "security");
    }
    public function init(): bool { 
        $fc = igk_configs()->get(self::SYS_PROPERTY);
        if ($fc && file_exists($fc)){
            $this->_initSetting($fc);
            return true;
        }
        //check if 
        //found the 
        $base = Path::LocalPath(igk_io_basedir());
        while(! ($found = file_exists($fc = $base."/.ovhconfig"))){
            if ($base == ($c=dirname($base))){
                break;
            }
            $base = $c;
        }
        if ($found){
            igk_configs()->{"ovh.ovhconfig"} = $fc; 
            $this->_initSetting($fc);           
            igk_configs()->saveData();
            return true;
        }
        return false;
    }

    public function __sleep(){
        return [];
    }
    public function __wakeup(){

    }
    public function enable_firewall_uri(){
        return igk_register_temp_uri($this, ServiceController::ctrl())."/enable_firewall";
    }
    public function disable_firewall_uri(){
        return igk_register_temp_uri($this, ServiceController::ctrl())."/disable_firewall";
    }

    public function disable_firewall($nav=1){
        if (( $file = igk_configs()->{self::SYS_PROPERTY}) 
        && file_exists($file)){
            $ini = IniFile::LoadConfig($file);
            if ($ini->{"http.firewall"} == "security"){
                $ini->comment("http.firewall");                
                $ini->store($file);
            } 
        }
        if ($nav)
            igk_navto_referer();
    }
    public function enable_firewall($nav=1){
       
        if (( $file = igk_configs()->{self::SYS_PROPERTY}) 
        && file_exists($file)){
            $ini = IniFile::LoadConfig($file);
            if ($ini->{"#http.firewall"} == "security"){
                $ini->activate("http.firewall");                                
            } else {
                $ini->{"http.firewall"} = "security";
            }
            $ini->store($file);
        }
        if ($nav)
        igk_navto_referer();
    }


}