<?php
// @author: C.A.D. BONDJE DOUE
// @file: %packages%/Modules/igk/js/Angular/global.php
// @desc: 
// @date: 20210828 15:15:41

// + module entry file 
use igk\js\Angular\AngularApp;

/**
 * create and bind angular application
 * @param mixed $t cibling node
 * @param mixed $dir build directory
 * @return AngularApp 
 */
function igk_angular_app($t, $dir, $doc=null, $name=null, $ctrl=null){
    if ($ctrl===null){
        $ctrl = igk_get_current_base_ctrl();
    }
    $n = new AngularApp();
    $t->add($n);
    if (is_dir($dir)){
        AngularApp::LoadApp($t, $dir, $doc, $ctrl, $name);
        $t->directory = $dir;
    }

    return $n;
}