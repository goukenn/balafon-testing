<?php

namespace igk\js\Vue3;


    function refvar(string $key){
        return new VueRefVariable($key);
    }
