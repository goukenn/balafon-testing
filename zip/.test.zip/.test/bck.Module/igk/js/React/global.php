<?php
// @author: C.A.D. BONDJE DOUE
// @file: %packages%/Modules/igk/js/React/global.php
// @desc: 
// @date: 20210914 11:39:25

// + module entry file 
function igk_html_node_ReactApp($name, $options= null){
    $n = igk_create_node("div");
    $n->setAttribute("id", $name);
    $n->balafonJs()->Content = igk_getv($options, "main.js",  <<<EOF
(function(n){
    // console.log('init react app');
    class App extends React.Component{ 
        constructor(props){
            super(props); 
        }
        render(){ 
            return React.createElement('div', {}, 'React Application. Hello world!!!! '+ this.props.name);
        }
    }
    var attr = {};
    var t = n.o.parentNode.attributes;
    for(var i = 0; i < n.o.parentNode.attributes.length; i++){
        attr[t[i].name] = t[i].value;
    } 
    ReactDOM.render(React.createElement(App, attr), n.o.parentNode);
})(this);
EOF
    );
    return $n;
}

