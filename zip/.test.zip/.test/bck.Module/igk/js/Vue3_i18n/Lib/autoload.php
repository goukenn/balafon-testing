<?php

use IGK\Controllers\BaseController;

BaseController::RegisterMacros();

