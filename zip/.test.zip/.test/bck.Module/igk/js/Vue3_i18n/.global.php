<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/js/n18n/.global.php
// @date: 20230303 09:50:37

// + module entry file 
