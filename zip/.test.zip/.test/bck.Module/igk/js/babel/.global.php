<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/js/babel/.global.php
// @date: 20230102 11:58:44

// + module entry file 
