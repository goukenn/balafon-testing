# igk/js/babel module 

Balafon's utility babel

- https://babeljs.io

add system command utility

- usage 

check the installed babel version 
```
balafon --babel --version : 
```



# author @C.A.D.BONDJEDOUE