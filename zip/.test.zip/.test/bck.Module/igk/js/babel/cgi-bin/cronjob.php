#!/usr/bin/env php
<?php
// @file: cronjob.php
// @date: 20230102 12:07:18
// @author: C.A.D. BONDJE DOUE
// @license: 

shell_exec("/Volumes/Data/wwwroot/core/Packages/Modules/igk/js/babel/Lib/igk/bin/balafon --run:cron --wdir:/Volumes/Data/wwwroot/core/Packages/Modules/igk/js/babel");