# wait me JS PLUGIN - 

# INSPIRED BY 

https://www.jqueryscript.net/blog/Best-Loading-Spinner-Indicator-jQuery-Plugins.html

