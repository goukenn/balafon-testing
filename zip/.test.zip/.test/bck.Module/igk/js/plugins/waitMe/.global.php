<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/js/plugins/waitMe/.global.php
// @date: 20220519 16:56:11

// + module entry file 

use IGK\Helper\Activator;
use igk\js\common\JSExpression;
use igk\js\plugins\waitMe\ConfigurationOptions;
use IGK\System\Html\Dom\HtmlItemBase;

/**
 * 
 * @param null|array|ConfigurationOptions $options 
 * @return HtmlItemBase<mixed, string> 
 * @throws IGKException 
 */
function igk_html_node_waitme(?array $options=null){
    $n = igk_create_node("div");
    $n["class"] = "igk-winui-waitme";
    $o = null;
    if ($options){
        if (is_array($options)){
            $o = Activator::CreateNewInstance(ConfigurationOptions::class, $options);
        } else if ($options instanceof ConfigurationOptions){
            $o = $options;
        }
        if ($o){
            $n["igk-data"] = JSExpression::Stringify((object)$o, (object)[
                "ignoreNull"=>1
            ]);
        }
    }
    return $n;
}