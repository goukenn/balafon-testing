<?php

igk_require_module(igk\docs\swagger::class);

use igk\docs\swagger\SwaggerBearerAuthInfo;
use igk\docs\swagger\SwaggerDocument;
use igk\docs\swagger\SwaggerInfo;
use igk\docs\swagger\SwaggerPathInfo;
igk_trace();

igk_exit();
$doc = new SwaggerDocument;
$info = new SwaggerPathInfo();
$info->description = 'return user';
$doc
->type(SwaggerDocument::OpenApi)
->addPath("/user", "get", $info); 
$doc->addServer("http://localhost:7300", "Develop server");
$doc->addServer("http://localhost:7301", "OPS Server");
$doc->setSecurity(new SwaggerBearerAuthInfo);
echo $doc->render();