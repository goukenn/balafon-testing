# igk/docs/swagger
 
@C.A.D.BONDJEDOUE

Help generate and render a swagger code documentation base on 


current version 3.0.0


```php
$doc = new SwaggerDocument
$doc->setTitle("title")
->setDesc('description);
```

call render to render the definition

In project 
```php
igk_require_module(igk\docs\swagger::class);
// ...
// then 
// ...
$t->swagger_app($ctrl);

```

## add response to method

- use json declaration view swagger documentation for reponse section
```php
class DoAction{
    /**
     * @responses({"200":{ 
     * "content":{
     *      "application/json":{
     *          
     *      }
     * }
     * }),
     * @request({ 
     *    "description":""
     * })
     */
    public function users(){

    }
}
```


- explicit use of a json in %project_swagger_dir%/responses/do/users.json 
```php
class DoAction{
    /**
     * @responses("responses/do/users")
     */
    public function users(){

    }
}
```


- use as api response - 
```php
class DoAction{
    /**
     * @responses() 
     */
    public function users(){

    }
}
```

- use security on a method

```php
class DoAction{
/*
* @security(["BearerAuth"])
*/
public function action(){

}
```


