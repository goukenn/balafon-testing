<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/docs/swagger/.global.php
// @date: 20230103 22:39:02

// + module entry file 

use IGK\Controllers\BaseController;
use igk\docs\swagger\Components\AppNode;
use igk\docs\swagger\Components\AppOptions;
use igk\docs\swagger\SwaggerGenerator;

/**
 * 
 * @param array|AppOptions $options 
 * @return AppNode<mixed, mixed> 
 */
function igk_html_node_swagger_app($options){
    $n = new AppNode();
    $n['data-options'] =
        SwaggerGenerator::CreateContentCallback($options);    
    return $n;
};
