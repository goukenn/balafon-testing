<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/google/flutter/.global.php
// @date: 20221228 16:45:46

// + module entry file 
