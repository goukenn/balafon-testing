<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/io/GraphQl/.global.php
// @date: 20221104 19:24:11

// + module entry file 
