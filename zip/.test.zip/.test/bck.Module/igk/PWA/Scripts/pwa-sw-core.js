"use strict";

const q = this;
let cacheName = '/pwa-service-worker';
let version = '1.0';
let entryCache = '';
let params = null;
let config = null;
const fileToCaches = [
    "./",
    "./assets/favicon.ico",
    "./manifest"
];

if (config = (new URL(location)).searchParams.get('config')) {
    params = JSON.parse(config);
    if (params) {
        cacheName = params.cacheName || cacheName;
        version = params.version || version;
    }
}

entryCache = cacheName + "-" + version;

q.addEventListener('install', async(event) => {
    console.debug("SW::" + event.type);
    event.waitUntil(new Promise(async(resolve, reject) => {
        await caches.open(entryCache).then(cache => {
            cache.addAll(fileToCaches);
        });
        resolve();
    }));
});
q.addEventListener('activate', (event) => {
    console.debug("SW::" + event.type);
    var rg = new RegExp("^".cacheName);
    event.waitUntil(
        caches.keys().then((keys) => {
            return new Promise(async function(resolve, reject) {
                await keys.filter(k => rg.test(k) && (k != entryCache)).map(i => caches.delete(i));
                resolve();
            });
        })
    );
});
q.addEventListener('message', (event) => {
    /// receive message from client
    // console.debug("SW::"+event.type);
    var d = JSON.parse(event.data);
    if (d && (typeof(d) == 'object')) {
        switch (d.type) {
            case 'install':
                let cacheList = [];
                let response = [];
                d.data.map(i => {
                    if (typeof(i) == 'string') {
                        cacheList.push(i);
                    } else {
                        // styling
                        response.push({
                            uri: i.uri,
                            response: new Response(
                                i.data, {
                                    headers: {
                                        "Content-Type": i['content-type'],
                                        "Content-Length": i.data.length
                                    }
                                }
                            )
                        });
                    }
                });

                caches.open(entryCache).then(async(cache) => {
                    // console.debug("load cached entries")
                    await cache.addAll(cacheList);
                    // console.debug("load response");
                    response.map(i => cache.put(i.uri, i.response));
                });

                break;
            default:
                console.debug('not handle type ' + type);
                break;
        }
    }
});
q.addEventListener('fetch', (event) => {
    // console.debug("SW::"+event.type); 
    /// TODO: FETCH
    event.respondWith(
        caches.match(event.request).then(
            (response) => {
                // Cache hit - return response
                if (response) {
                    return response;
                }

                var fetchRequest = event.request.clone();
                return fetch(fetchRequest).then(
                    (response) => {
                        if (!response || (response.status != 200) || (response.type != "basic")) {
                            return response;
                        }
                        var repToCache = response.clone();

                        caches.open(entryCache).then(cache => {
                            console.debug("cache to ", event.request);
                            cache.put(event.request, repToCache);
                        });
                        return response;
                    }
                );
            }
        )
    );
});