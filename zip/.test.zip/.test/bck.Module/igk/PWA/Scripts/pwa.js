// @file: 
// @description: pwa helper 
"use strict";
(function() {
    if (!igk)
        return;
    var protocol = document.location.protocol;
    if (!/^http(s)?:/.test(protocol)) {
        return;
    }
    igk.system.createNS("igk.PWA", {
        init: function(serviceWorker, options) {
            if (!serviceWorker.ready) {
                return;
            }
            let cacheEntry = options.cacheName + options.version;

            // + | passing initial data to service worker
            serviceWorker.ready.then(function(registration) {
                var sc = [];
                Array.prototype.map.call(document.scripts, function(e) {
                    var s = e.getAttribute('src');
                    if (s)
                        sc.push(s);
                });
                //+
                // load images present on view
                //+
                Array.prototype.map.call(document.images, function(e) {
                    var s = e.getAttribute('src');
                    if (s)
                        sc.push(s);
                });

                //+
                // load stylesheets
                //+
                Array.prototype.map.call(document.styleSheets, function(e) {
                    var s = e["href"]; //.getAttribute('href');
                    var txt = "";
                    if ("rules" in e) {
                        try {
                            Array.prototype.map.call(e.rules, function(m) {
                                txt += m.cssText + "\n";
                            });
                        } catch (ex) {
                            // no rules properties for extra file;// console.log("failed to read rules", s,  e, ex);
                            // sc.push(s);
                            return;
                        }
                    }
                    if (s)
                        caches.open(cacheEntry).then(function(cache) {
                            cache.put(s, new Response(txt, {
                                headers: {
                                    "Content-Type": "text/css",
                                    "Content-Length": txt.length
                                }
                            }));
                        });
                });
                // + post presetation message
                // registration.active.postMessage(JSON.stringify({
                //     "type":"resource",
                //     "options":options,
                //     "data":sc
                // }));

            });
        },
        loadedData() {
            var sc = [];
            Array.prototype.map.call(document.scripts, function(e) {
                var s = e.getAttribute('src');
                if (s)
                    sc.push(s);
            });
            //+
            // load images present on view
            //+
            Array.prototype.map.call(document.images, function(e) {
                var s = e.getAttribute('src');
                if (s)
                    sc.push(s);
            });
            //+
            // load stylesheets
            //+
            Array.prototype.map.call(document.styleSheets, function(e) {
                var s = e["href"]; //.getAttribute('href');
                var txt = "";
                if ("rules" in e) {
                    try {
                        Array.prototype.map.call(e.rules, function(m) {
                            txt += m.cssText + "\n";
                        });
                    } catch (ex) {
                        return;
                    }
                }
                if (s) {
                    sc.push({
                        "type": "css",
                        "uri": s,
                        "content-type": "text/css",
                        "data": txt
                    });
                }
            });
            return sc;
        }
    });

    (function() {
        var installworker_event = null;
        var app_options = null;
        const _fc = "function";
        var install_btn = null;

        let _prom = 0;
        let _show = function(t, e) {
            return function() {
                if (t == 'btn') {
                    this.on("click", () => {
                        if (!_prom) {
                            e.prompt();
                            _prom = 1;
                        }
                    });
                }
                this.addClass('show');
            };
        };

        igk.ready(function() {
            install_btn = $igk(".pwa-btn-install").first();
            if (install_btn) {
                install_btn.on("click", function(e) {
                    igk.PWA.worker.prompt();
                });
            }
        });

        if ('serviceWorker' in window.navigator) {
            var service = window.navigator.serviceWorker;

            igk.winui.initClassControl("igk-js-pwa", function() {
                var src = this.o.textContent;
                var fc = new Function("serviceWorker", "options", src);
                var reg_fc = null;
                var options = JSON.parse(this.getAttribute("igk:js-pwa-options"));
                app_options = options;
                if (app_options.complete) {
                    if (typeof(app_options.complete) == 'string') {
                        reg_fc = igk.system.getNS(app_options.complete);
                    } else if (typeof(app_options.complete) == 'function') {
                        reg_fc = app_options.complete;
                    }
                }
                var base_func = service.register;
                var registered = false;
                // + | ------------------------------------------------
                // + | inject custom registration service
                // + | ------------------------------------------------
                service.register = function(uri, options) {
                    registered = true;
                    return base_func.apply(this, [uri, options]);
                };
                fc.apply(service, [service, app_options]);

                // + | restore base function 
                service.register = base_func;
                if (!registered) {
                    service.__options = app_options;
                    service.register(app_options.serviceworkerURL, app_options.scope ? { scope: app_options.scope } : null).then(function(e) {
                        if (reg_fc) {
                            reg_fc.apply(service, [e, app_options]);
                        }
                    }).catch(function(e) {
                        console.log("Can't register service worker");
                        console.debug("Failed: ", e);
                    });
                }
                igk.PWA.init(service, app_options);
                this.remove();
            });

            // + | install prompt
            if ('onbeforeinstallprompt' in window)
                igk.winui.reg_event(window, "beforeinstallprompt", function(e) {
                    installworker_event = e;
                    if (install_btn)
                        install_btn.rmClass("dispn");
                    if (app_options && (typeof(app_options.beforeinstallprompt) == _fc)) {
                        app_options.beforeinstallprompt.apply(this, [e]);
                    }
                    $igk(".pwa-install-button").each_all(_show('btn', e));
                    $igk(".pwa-container").each_all(_show('container', e));
                });

            // + | uninstall prompt
            if ('onappinstalled' in window)
                igk.winui.reg_event(window, "appinstalled", function(e) {
                    console.debug("app installed ");
                    installworker_event = null;
                    if (install_btn)
                        install_btn.addClass("dispn");
                    if (app_options && (typeof(app_options.installed) == _fc)) {
                        app_options.installed.apply(this, [e]);
                    }
                });
        }
        igk.system.createNS("igk.PWA.worker", {
            prompt() {
                if (installworker_event) {
                    installworker_event.prompt();
                } else {
                    console.debug("no installworker_event");
                }
            }
        });
    })();
})();