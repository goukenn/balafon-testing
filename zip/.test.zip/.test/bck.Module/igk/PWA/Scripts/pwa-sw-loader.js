"use strict";
(function () {
    let options = JSON.parse('{{ %options% }}');
    // console.debug(options);
    function installLocal(registration) {
        var d = igk.PWA.loadedData();
        registration.active.postMessage(JSON.stringify({ "type": "install", "data": d }));
    }; 
    function log(){
        options.debug && console.log.apply(null , arguments);
    };
    if ('serviceWorker' in window.navigator) { 
        let mainSW = window.navigator.serviceWorker;        
        var installed = !1;
        var _uri = (new URL(options.scriptURL, document.baseURI)).href;

        const register = async function () {
            await mainSW.getRegistrations().then(r => {
                var g = r.filter((i) => (i.active &&  (i.active.scriptURL == _uri)));
                installed = g.length == 1;
            });
            mainSW.register(_uri, { scope: options.scope }).then(() => {
               log("****** register ***** ");
            });
            if (!installed) {
                mainSW.ready.then(installLocal);
            }
        };
        register();
    }
    else {
        log('no service worker present');
    }

})();