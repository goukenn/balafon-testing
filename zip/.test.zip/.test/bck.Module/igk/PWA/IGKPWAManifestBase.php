<?php
namespace igk\PWA;

abstract class IGKPWAManifestBase{
    abstract function icons($x=144,$y=null);
    abstract function manifest();
    abstract function serviceworker();
}