<?php
//PWA: progressive web application

///<summary>get pwd direct module</summary>

use IGK\System\Html\Dom\HtmlCallbackValueAttribute;
use IGK\System\Html\Dom\HtmlItemBase;
use IGK\System\Html\Dom\HtmlNode;
use igk\PWA\IPWAServiceOptions;
/**
 * get pwa direct module
 * */
function igk_pwa_module(){
	return igk_get_module(igk_get_module_name(dirname(__FILE__)));
}
function igk_pwa_init_doc(IGKHtmlDoc $doc, $settings=null){
	$ctrl = igk_pwa_module();
	$n = $doc->head->addsingleNodeViewer(IGK_HTML_NOTAG_ELEMENT);
	$n->setIndex(-10);
	// add manifest 
	$n->targetNode->add(new igk\PWA\Html\ManifestNode($ctrl, igk_getv($settings, "manifest")));
	// add apple touch icon
	$n->targetNode->add(new igk\PWA\Html\AppleTouchIcon($ctrl, igk_getv($settings, "apple-touch-icon"))); 
	// add a core module pwa.js
	$doc->addScript($ctrl->getScriptsDir()."/pwa.js", "pwa", false)->activate('defer'); 
	// need to register a service worker 	
	$doc->getBody()->setClass("+pwa"); 
	if (!$doc->getHeaderColor()){
		$doc->setHeaderColor("#000");
	}  
	//define document for pwa handling
	define("PWA_APP", 1);
	if (!defined("IGK_NO_BASEURL"))
		define('IGK_NO_BASEURL', 1);
}

///<summary>protect directory entry</summary>
function igk_pwa_protect_entrydir($ctrl){ //pwa entry directory protection
	extract (igk_get_view_args());
	
	if (!$is_direntry && count($params)==0){
	$ctrl->setParam("redirectpost", $_POST);
	$query = igk_getv(parse_url(igk_io_request_uri()), "query");
	if ($query)
		$query = "?".$query;
		igk_navto($entry_uri.'/'.$query);	
	}else{
		$p = $ctrl->getParam("redirectpost");
		$ctrl->setParam("redirectpost", null);
		
		if ($p){
			$_POST = $p;//retrieve the posted value
		}		
	}
};


function igk_pwa_script($name, $data){ 
	$ctrl = igk_get_module(igk_get_module_name(dirname(__FILE__)));
	if($ctrl){
		extract($data); 
		include($ctrl->getScriptsDir()."/{$name}.pjs");
	}else{
		igk_ilog("module ctrl not found");
	}
}
//pwa items 

/// COMPONENTS
///
///register service worker
///
function igk_html_node_jsserviceworker($uri, $scope=null){
	$js = igk_create_node("script");	
	$opts ="";
	if ($scope){
		$opts.=", {scope:'{$scope}'}";
	}	
	$js->addObData(function()use($uri, $opts){
		igk_pwa_script('default', array("uri"=>$uri, 'opts'=>$opts));
	},null);
	return $js;
}

/**
 * builder iniline service worker
 * @param mixed $options will store setting JSPWA passed a json
 * 		base: the base url
 * 		serviceworkerURL: url to service worker 
 * */
function igk_html_node_JSPWA($options=null){
	$n = igk_create_node("script");
	$n["type"] = "text/js-pwa-script";
	$n["class"] = "igk-js-pwa";
	if ($options===null){
		$options = (object)[
			"base"=>igk_io_baseuri(),
			"serviceworkerURL"=>"./serviceworker",
			"cacheName"=>"v1"
		];
	}
	$n["igk:js-pwa-options"] = json_encode($options);
	return $n;
}
/**
 * build install button
 * @return HtmlNode 
 */
function igk_html_node_pwa_install_button(){
	$n = new HtmlNode("div");
	$n["class"] = "igk-btn pwa-btn-install dispn";	
	return $n;
}
/**
 * 
 * @param ?\igk\PWA\IPWAServiceOptions|?array $options [scope, base, serviceworkerURL, cacheName ]
 * @return HtmlNode
 * @throws IGKException 
 */
function igk_html_node_pwa_script($options = null){	
	$n = igk_create_node("script");
	$n["type"] = "text/js-pwa-script";
	$n["class"] = "igk-js-pwa";
	if (is_null($options)){
		$options = (object)[
			"base"=>igk_io_baseuri(),
			"serviceworkerURL"=>"./serviceworker",
			"cacheName"=>"v1"
		];
	}
	if ($options){
		$n["igk:js-pwa-options"] = json_encode($options, JSON_UNESCAPED_SLASHES);
	}
	return $n;
}

function igk_html_node_pwa_install_script($options, ?string $id = null){
	static $src;
	$mod = igk_pwa_module();
	if ($src === null){
		$src = file_get_contents($mod->getScriptsDir()."/pwa-sw-loader.js");
	}

	$c = str_replace("{{ %options% }}", json_encode($options,
JSON_UNESCAPED_SLASHES), $src);
	$n = new HtmlNode("script");
	$n->setId($id);
	$n->Content = $c; 
	return $n;

}