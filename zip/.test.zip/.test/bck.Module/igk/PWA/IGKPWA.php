<?php
namespace igk\PWA;


/**
 * represent a progressive web application builder 
 * */
class IGKPWA{ 
    /**
     * manifest info
     * @var object
     */
    var $info;

    public function __construct($appName, $entryuri, $version="1.0", $shortname=null, $desc="")
    {
        $this->info = new PWAManifest;//(object)array(); 
		$this->info->version = $version;
        // define id : important
        $this->info->id = "/";
		$this->info->name = $appName;
        $this->info->short_name= $shortname? $shortname: substr($appName,0, 8);
        $this->info->start_url =  $entryuri; // "https://igkdev.com/testapi/wpa/";
        $this->info->description = $desc;
        $this->info->display = "fullscreen";
        $this->info->orientation = "portrait"; // landscape
        $this->info->theme_color = "blue";
        $this->info->background_color = "#4fce87";
        $this->info->lang = "fr";
        $this->info->icons = array();
    }
    public function __set($v, $m){
        if (\property_exists($this->info, $v)){
            $this->info->{$v} = $m;
        }
    }
    public function __get($v){
        return igk_getv($this->info, $v, null);
    }
    public function addIcon($size, $path, $mimetype="image/png"){
        $this->info->icons[] = array(
            "type"=>$mimetype,
            "sizes"=>$size,
            "src"=>$path
        ); 
    }
    public function addMaskableIcon($size, $path, $mimetype="image/png"){
        $this->info->icons[] = array(
            "type"=>$mimetype,
            "sizes"=>$size,
            "src"=>$path,
            "purpose"=>'maskable'
        ); 
    }
    /**
     * render manifest
     * */
    public function manifest(){       
		echo igk_json(json_encode($this->info, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT)); 
    }
}