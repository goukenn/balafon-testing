<?php
namespace igk\PWA;

use IGK\System\Polyfill\JsonSerializableTrait;
use JsonSerializable;
use Reflection;

/**
 * represent manifest definition 
 */
class PWAManifest implements JsonSerializable{
    use JsonSerializableTrait;

    var $name; 
    var $short_name;
    var $id;
    var $start_url = "./";   
    var $scope;
    var $orientation = "portrait";
    var $display = "standalone";
    var $background_color = "#000";
    var $theme_color = "#000";
    var $description;
    var $categories;
    var $display_override;
    var $note_taking;
    /**
     * register protocol handler [{protocol: type, url: path} ... ]
     * @var array
     */
    var $protocol_handlers = [];
    var $dir;
    var $lang;
    var $icons = [];
    var $prefer_related_applications = true;
    var $related_applications = [];

    var $screenshots; 


    const DISPLAYS = ["standalone", "fullscreen", "minimal-ui"];

    /**
     * .ctr
     * @return void 
     */
    public function __construct(){        
    }
    protected function _json_serialize(){
        return array_filter((array)$this);
    }
    public static function Create(array $definition){
        $inf = [];
        foreach(array_keys(get_class_vars(static::class)) as $k ){
            if ($m = igk_getv($definition, $k)){
                $inf[$k] = $m;
            }
        }
        // + | missing variable check 

        $m = new static();
        foreach($inf as $k=>$v){
            $m->$k = $v;
        }
        return $m;
    }
}