<?php

namespace igk\PWA;

use IGK\System\Http\Request;
use IGK\System\Http\RequestResponse;

interface IServiceWorkerViewActionHandler{
    function manifest() : ?RequestResponse;
    function service_worker() : ?RequestResponse;
    function assets(Request $request) :?RequestResponse;
}