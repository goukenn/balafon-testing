<?php
// @author: C.A.D. BONDJE DOUE
// @filename: PWAManifestIcons.php
// @date: 20221007 09:07:27
// @desc: manifests icons definition 

namespace igk\PWA;

/**
 * manifest icons definition
 * @package 
 */
class PWAManifestIcons{
    var $src;
    var $type;
    var $sizes;
    /**
     * icon purpose \
     * can be defined to one of this values : \
     * any|monochrone|maskable
     * @var mixed
     */
    var $purpose;

    public function __construct(string $url, string $sizes, $type="image/png"){
        $this->src = $url;
        $this->sizes = $sizes;
        $this->type = $type;
    }
}
