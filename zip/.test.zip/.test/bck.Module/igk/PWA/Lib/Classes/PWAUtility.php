<?php

// @author: C.A.D. BONDJE DOUE
// @filename: PWAUtility.php
// @date: 20221009 01:04:29
// @desc: 

namespace igk\PWA;

/**
 * init service worker
 * @package igk\PWA
 */
class PWAUtility{
    public static function registerServiceWorker($target, $options){
        $service_worker = igk_getv($options, "service_worker");
        $scope = igk_getv($options, "scope");
$target->script()->Content = <<<JS
igk.ready(()=>{
if ('serviceWorker' in navigator){ 
    let _prom = 0;
    let _show = function(t, e){
        return function(){
            if (t == 'btn'){
                this.on("click", ()=>{
                    if (!_prom){
                        e.prompt();
                        _prom = 1;
                    }
                });
            }
            this.addClass('show');
        };
    };
    window.addEventListener("beforeinstallprompt", (e)=>{
        \$igk(".pwa-install-button").each_all(_show('btn', e));
        \$igk(".pwa-container").each_all(_show('container', e));
    });

    window.addEventListener("appinstalled", (e)=>{
        console.log("application installed");
    });
    // entry uri sw must set Service-Worker-Allowed '/'
    navigator.serviceWorker.register('{$service_worker}',{ 
        scope:'{$scope}/'
    });
    // .then(()=>{
    //     console.log('perfect registered');
    // }).catch((e)=>{
    //     console.log('failed to register : {$service_worker}', e);
    // })
}
});
JS;
}
}
