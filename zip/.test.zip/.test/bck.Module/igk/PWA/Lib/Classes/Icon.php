<?php
namespace igk\PWA;

use IGK\System\Polyfill\JsonSerializableTrait;
use JsonSerializable;

/**
 * represent manifest icons definition
 * @package igk\PWA
 */
class Icon implements JsonSerializable{
    use JsonSerializableTrait;
    /**
     * icon source uri
     * @var string
     */
    var $src;

    /**
     * size of icons. space separated resolutions widthxheight
     * @var mixed
     */
    var $sizes;
    /**
     * icons density
     * @var int
     */
    var $density;

    /**
     * type of the icons. image/webp default is icon
     * @var string
     */
    var $type;

    /**
     * 
     * @var mixed
     */
    var $purpose;

    // any maskable icons
    const PURPOSE_ANY_MASKABLE = "any maskable";

    protected function _json_serialize(){ 

        return array_filter((array)$this);

    }

}