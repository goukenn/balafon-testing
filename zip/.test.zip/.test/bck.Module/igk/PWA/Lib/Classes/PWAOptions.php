<?php
namespace igk\PWA;

class PWAOptions{
    /**
     * uri to service worker
     */
    var $serviceworkerURL;

    /**
     * scope
     */
    var $scope;
}