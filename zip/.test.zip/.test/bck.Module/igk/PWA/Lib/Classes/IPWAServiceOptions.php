<?php

namespace igk\PWA;
/**
 * 
 * @package 
 * @property string $scope scope of the service worker;
 * @property string $base base uri;
 * @property string $serviceworkerURL service worker access script ;
 * @property string $cacheName cache name ;
 */
interface IPWAServiceOptions{

}