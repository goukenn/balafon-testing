<?php



final class IGKWPALinkCacheDocument
{
	var $tab; 
	var $ln;
	public function __construct(& $tab, $ln=null, $doc=null){
		$this->tab = & $tab; //marking the array to update 
		$this->ln = $ln ?? strlen(igk_io_rootdir());
	}
	public function addTempScript($dir){
		if (file_exists($dir)){
			$this->tab[] = igk_uri(substr($dir, $this->ln)); 
		}
	} 
	public function cacheLib($dir, $s="/\.(js|png|jp(e)?p|json)$/"){
		igk_io_getfiles($dir, function($f)use($s){
			if ((basename($f)[0]!='.') && preg_match($s, $f)){
				$this->tab[] = igk_uri(substr($f, $this->ln));
			}			
		});
	}  
}