<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igkSwiftFileBuilder/.global.php
// @date: 20220910 11:09:53

// + module entry file 
