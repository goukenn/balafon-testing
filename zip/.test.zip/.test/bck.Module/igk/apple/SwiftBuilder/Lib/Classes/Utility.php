<?php
namespace igk\apple\SwiftBuilder;

abstract class Utility { 
    /**
     * return swift type from model
     * @param mixed $type 
     * @return mixed 
     * @throws IGKException 
     */
    public static function GetSwiftType($type, $core_data = false){
        return igk_getv([
            "int"=>$core_data ? "NSNumber": "Int",
            "float"=>$core_data ?"NSNumber": "Float",
            "double"=>$core_data ?"NSNumber":"Double",
            "date"=>$core_data ? "NSDate": "String",
            "datetime"=>"String",
            "timestamp"=>"String",
            "varchar"=>"String",
            "text"=>"String",
            "blob"=>"String",
            "json"=>"String",
            "enum"=>"String",
        ], strtolower($type), "Any");
    }
}