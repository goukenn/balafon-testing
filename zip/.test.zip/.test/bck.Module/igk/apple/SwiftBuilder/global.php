<?php
// @author: C.A.D. BONDJE DOUE
// @file: %packages%/Modules/igk/apple/SwiftBuilder/global.php
// @date: 20211014 18:35:30

// + module entry file 
