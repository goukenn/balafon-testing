trois information importante 
l'utilisateur: account
le mot de passe : client Id 
la signature : secret

