<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/pay/paypal/global.php
// @date: 20211008 13:51:49

// + module entry file 

use igk\pay\paypal\Html\paypalButton;
use igk\pay\paypal\paypalACKResponse;
use igk\pay\paypal\paypalConstant;
use igk\pay\paypal\paypalParams;
use igk\pay\paypal\paypalPayementTransaction;
use igk\pay\paypal\paypalPaymentCredentials;
use igk\pay\paypal\paypalPaymentResponse;
use IGK\Resources\R;

/**
 * create a paypal button
 * @return void 
 */
function igk_html_node_paypal_button(array $option=null){
    $n = new paypalButton($option);  
    return $n;
}






//register paypal service
igk_register_service("payment", "paypal", function($cmd, $n){ 
	$tab = array_slice(func_get_args(),2);
	$ctrl  = igk_getctrl( \igk\pay\paypal\Component\paypalpaymentCtrl::class);
		switch($cmd){
			case "store":			
			$p = $ctrl->getParam("args");
			if (!$p)return false;			
			$ctrl->setParam("args", null);
			$o = igk_getr_k(array("UserId", "UserPwd", "ApiKeySignature", "Production"));			
			// $s = $ctrl->getParam("args");			
			$_REQUEST["clPaymentArgs"] = $o;			
			$u = igk_getv($p, "storeuri");			
			igk_sys_invoke_uri($u);
			
			break;
			case "configure":
				$o = igk_getv($tab, 1);
				$uri = igk_getv($tab, 0);
				$d = $n;
				$d->addNotifyHost("btv://storepayment");
				$frm = $d->addForm();	
				$frm["action"] = $ctrl->getUriCommand("invokecmd", array("storeuri"=>$uri));
				
				// $o = igk_conf_get($ctrl->Configs,'app.Payments/paypal');
				$ul = $frm->add("ul");
				$bck = $_REQUEST;
				if ($o){
					$_REQUEST = (array)$o;
					
				}
				
				igk_html_build_form($ul, array(
					"clPaymentType"=>array("type"=>"hidden", "attribs"=>array("value"=>"paypal")),
					"Production"=>array("require"=>1,"type"=>"checkbox", "attribs"=>array("value"=>"1")),
					"UserId"=>array("require"=>1),
					"UserPwd"=>array("require"=>1,"type"=>"password"),
					"ApiKeySignature"=>array("require"=>1),
				));
				
				$dv = $frm->div();
				$dv->addSectionTitle(3)->Content = "REST API KEY";
				
				igk_html_build_form($dv, array(
				"RestSandbox"=>["attribs"=>["value"=>""]],
				"RestProduction"=>["attribs"=>["value"=>""]],
				));
				
				
				$frm->addInput("btn_v", "submit", R::ngets("btn.save"));
				
				// $d->addArrayData((array)$ctrl->Configs->paypal);
				// $d->addArrayData((array)igk_conf_get($ctrl->Configs,'app.Payments/paypal'));
				// $d->addArrayData((array)$ctrl->Configs);
				// $ctrl->storeConfigSettings();
		
				if ($ctrl){					
					$d-> addDiv()->setClass("floatr")->addImg()->setSrc($ctrl->getImgVertical("pp_cc_mark_74x46"));
				}
				$_REQUEST= $bck;	
			break;
			case "paybutton":
				
				$k = "paypal://button/".igk_io_request_uri();
				$t = igk_env_count($k);
				
				if (igk_getv($tab,4)){
					//$d->ClearChilds();
					//reset node callback
					$listener =  igk_app()->session;
					$c = $listener->getParam(IGK_NAMED_NODE_PARAM);
					unset($c[$k."/".$t]);
					$listener->setParam(IGK_NAMED_NODE_PARAM, $c);
					
				}
				
				
				$d = $n->addComponentNodeCallback(igk_app()->session, $k."/".$t, function($s,$n){
					return igk_create_node('PaypalButton');
				});
				// if (igk_getv($tab,4)){
					// $d->ClearChilds();
				// }
				
				$d->setGoodUri(igk_getv($tab,0))
				->setCancelUri(igk_getv($tab,1))
				->setAmount(max(1, igk_getv($tab,3)));
				
				$credential = igk_getv($tab,2);
				if ($credential){
					$d->setCredential(
						igk_getv($credential, "UserId"), 
						igk_getv($credential, "UserPwd"),
						igk_getv($credential, "ApiKeySignature")
					);
				}	
				$d->setProduction(igk_getv($credential, "Production"));
				$d->setDesc(igk_getv($tab,4));
				$d->Content = "Paypal";				
				return $d; 
			case "validate":
				//igk_ilog("validation de la commande");			
				$credential = igk_getv($n, "credential");
				$uri = paypalConstant::TEST_URI;
				if ($credential === null){
					$c = igk_getv($n, "host")??igk_die("no host specified");
					$credential = igk_conf_get($c->Configs, "app.Payments/paypal");				
					//$credential = paypalPaymentCredentials::Create($credential->UserId, $credential->UserPwd, $credential->ApiKeySignature);
					if (igk_getv($credential,"Production")){
						$uri = paypalConstant::PRODUCTION_URI;
					}
				}
				
				if (!$credential ){
					igk_die("no credential");
				}
			
				igk_paypal_validate(
				igk_getv($n, "uri", $uri),
				$credential,
				igk_getv($n, "callback")
				);
			
				// $payerid = igk_getr("PayerID");
				// $token = igk_getr("Token");				
				// if ($payerid){
					
					
					
					
					// if (method_exists($n,"validatePayment")){
						// return $n->validatePayment($payerid);
					// }else{
						// if (is_callable($n)){
							// return $n($payerid);
						// }						
					// }
				// }
				return 0;	 
			case "paylogo":
				$n->addImg()->setStyle("width:37px; height:23px")->setSrc($ctrl->getImgVertical("pp_cc_mark_74x46"));
				break;
			case "payerdetail"://return payer details
					$m = new paypalParams();
					$m->Method = paypalConstant::METH_GETEXPRESSCHECKOUTPAYMENTDETAILS;
					$m->PAYERID = igk_getv($n,"payerid");
					$m->TOKEN = igk_getv($n,"token");
					$credential = igk_getv($n, "credential");					
					$credential = paypalPaymentCredentials::Create(trim($credential->UserId),
						trim($credential->UserPwd), 
						trim($credential->ApiKeySignature)
						);
				 
					return paypalPayementTransaction::SendUri (igk_getv($n, "uri", paypalConstant::TEST_URI), $m, $credential);
			 
			case "confirm":
				$m = new paypalParams();
				$m->Method = paypalConstant::METH_DOEXPRESSCHECKOUTPAYMENT;
				$uri = igk_getv($n, "uri", paypalConstant::TEST_URI);
				$m->PAYERID = igk_getv($n,"payerid");
				$m->TOKEN = igk_getv($n,"token");
				$credential = igk_getv($n, "credential");					
				$credential = paypalPaymentCredentials::Create($credential->UserId, $credential->UserPwd, $credential->ApiKeySignature);
					
				$m->CURRENCYCODE = igk_getv($n, "currencycode") ?? igk_die("no currency code defined");
				$m->AMT = igk_getv($n, "amount") ?? igk_die("amount not defined");
				$m->PaymentAction = igk_getv($n, "paymentaction") ?? igk_die("PaymentAction required");
				// $m->AMT = $this->Amount;
				// $m->PaymentAction = $this->Type;
				$out = "?".$credential->getUri()."&VERSION=".paypalConstant::VERSION;
				if ($m)
				{
					$out .= "&".$m->getUri();
				}
				$tab =  igk_getquery_args($out);
				$o = paypalPaymentResponse::Create(igk_curl_post_uri($uri, $tab));
				//$this->m_response = $o;				
				if ($o->ACK == paypalACKResponse::SUCCESS)
				{
					return true;
				}
				else 
					return false;
			 
			default:
			igk_die("command {$cmd} not implements");
			break;
		}
		return false;
});

