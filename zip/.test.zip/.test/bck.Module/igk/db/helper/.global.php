<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/db/helper/.global.php
// @date: 20221201 09:26:19

// + module entry file 
