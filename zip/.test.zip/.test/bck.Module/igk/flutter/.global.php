<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/flutter/.global.php
// @date: 20221228 16:38:24

// + module entry file 
