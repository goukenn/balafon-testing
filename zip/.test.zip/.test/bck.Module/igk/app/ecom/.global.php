<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/app/ecom/.global.php
// @date: 20220427 10:50:48

// + module entry file 
