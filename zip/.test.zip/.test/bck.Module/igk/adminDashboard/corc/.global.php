<?php
// @author: C.A.D. BONDJE DOUE
// @file: %modules%/igk/adminDashboard/corc/.global.php
// @date: 20230215 13:27:31

// + module entry file 
