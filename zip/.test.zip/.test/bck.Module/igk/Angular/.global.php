<?php
//name: igk/Angular
//module: balafon angular module
//author: C.A.D. Bondje DOUE
//version:1.2

///<summary>angular function </summary>
///<param name="dirname">directory where application is installed</param>
///<param name="nodedir">node_modules directory to used</param>
function igk_angular_get_scripts($dirname, $nodedir=null){
    
    $files = array();
    $nodedir  = $nodedir ?? $dirname."/../node_modules";
    if (!is_dir($nodedir)){
        throw new IGKAngularException("node_modules not found"); 
    }
    file_exists($zonejs = realpath($nodedir."/zone.js/dist/zone.js")) || igk_die("zone.js not found");
    
    $files[] = igk_io_baseUri($zonejs);

    foreach(igk_io_getfiles($dirname, "/\.js$/i") as  $v){
        if (preg_match("/^poly/i", basename($v)))
            continue;
        $files[] = igk_io_baseUri($v);
    }
    return $files;
}



//angular - component
function igk_html_node_AngularApp($directive, $script=null){
    $n = igk_create_xmlnode($directive);
    $host = igk_create_notagnode();
    $host->add($n);
	$host->app = $n;
    if ($script){
		$host->addAJXViewNode()->script()->Content = <<<EOF
\$igk('head >> style').each_all(function(){this.remove();});
igk.getCurrentScript().remove();
if (window.webpackJsonp){
	window.webpackJsonp = null; //reset the webpackJsonp to reset application
	delete(window.webpackJsonp);
}
EOF;
        if (is_string($script) && is_dir($script)){
            try{
                $script = igk_angular_get_scripts($script);
            }
            catch(Exception $ex){
                igk_ilog("Error : ".$ex->getMessage());
            }
        }
        if (is_array($script)){
            foreach($script as  $v){
				$b = ["src"=> $v, 
					"type"=>"text/javascript"];
				if (basename($v) != "zone.js"){
					$b["reloaded"] = '1';
				}
				
				$script = $host->script()->setAttributes(
						$b
					);
            }
        }
        else 
            $host->script()->setAttributes(["src"=> $script]);
		
		$host->addScriptInlineLoader();
    }
    return  $host;
}



class IGKAngularException extends Exception{
	public function __construct($msg){
		parent::__construct($msg);
	}
}