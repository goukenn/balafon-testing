<?php

namespace igk\svg;
use \IGKXmlNode;
use \IGKColor;
use \ArrayAccess;

// $extract image from pdf 
class IGKSvgDocument extends IGKXmlNode implements ArrayAccess{
	private $_node;
	const NS = "http://www.w3.org/2000/svg";
	const XLINK_NS = "http://www.w3.org/1999/xlink";
	
	public function __construct(){
		parent::__construct("igk:svg-document");
		$this->_node = igk_create_xmlnode("svg");
		$this->_node["xmlns"] = self::NS;
		$this->_node["xmlns:xlink"] = self::XLINK_NS;
	}
	public function _AddChild($child, $index = null){
		return call_user_func_array([$this->_node, __FUNCTION__], func_get_args());
	}
	public function getIsRenderTagName(){
        return false;
    }
	public function renderAJX(&$options = null) {
		header("Content-Type: application/xml");
		echo '<?xml version="1.0" encoding="UTF-8" standalone="no" ?>'."\n";
		$this->_node->renderAJX($options);
	}
    protected function __getRenderingChildren($option=null){
		return [$this->_node];
	} 
	
	public function OffsetExists($i){
		return isset($this->_node[$i]);
	}
	public function OffsetSet($i, $v){
		$this->_node[$i] = $v;
	}
	public function OffsetGet($i){
		if ($this->OffsetExists($i)){
			return $this->_node[$i];
		}
		return null;
	}
	public function OffsetUnset($i){
		 unset( $this->_node[$i]);
	}
	public function __isset($i){
		return $this->OffsetExists($i);
	}
}
