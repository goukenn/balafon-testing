<?php

function igk_io_svg_openfile($f){
	
}

?>