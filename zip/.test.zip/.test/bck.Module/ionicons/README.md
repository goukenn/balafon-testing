use ionicons
```
igk_require_module(ionicons::class);
```

igk_svg_use("ionicon_name")

#exemple: as content

```
 $t->div()->Content = igk_svg_use("warning-sharp");
```

#exemple: as node

```
 $t->div()->Content = igk_svg_use("warning-sharp");
```