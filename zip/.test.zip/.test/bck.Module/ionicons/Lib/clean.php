<?php

class Helper{
    static function sUri($u){
        return str_replace("\\", "/", $u);
    }
    public static function GetFiles($dir, $match, $recursive=false, & $excludedir=null, ?callable $callback=null){
      
        // igk_dev_ilog( __METHOD__ ." / ".$dir);

        if(is_dir($dir) === false)
            return null;
        $v_out=array();
        $dir= rtrim( self::sUri($dir), '/');
        $q=0;
        $dirs=array(); 
        array_push($dirs, $dir);
        $iscallable=is_callable($match);
        $sep='/';
        $fc=function(){
            return false;
        };
        if(is_string($excludedir)){
            $fc=function($d, $m, $ignoredname){
                return preg_match($ignoredname, $m);
            };
        }
        else if(is_array($excludedir)){
            $fc=function($d, $m, $ignoredname){
                return isset($ignoredname[$m]) || isset($ignoredname[$d]);
            };
        }
        while($q=array_pop($dirs)){
            if ($hdir=@opendir($q)){
            while($hdir && ($r=readdir($hdir))){
                if($r == "." || ($r == ".."))
                    continue;
                $mdata=0;
                $f=$q.$sep. $r;
                if(!is_dir($f) && (($iscallable && ($mdata=$match($f, $excludedir))) || ($match == null) || (is_string($match) && preg_match($match, $f)))){
                    if($mdata == -1){
                        continue;
                    }
                    $v_out[]=$f;
                    $callback && $callback($f);
                }
                else{
                    if(is_dir($f) && !$fc($f, $r, $excludedir) && $recursive){
                        array_push($dirs, $f);
                    }
                }
            }
            closedir($hdir);
            }
        }
        return $v_out;
    }
}


foreach( Helper::GetFiles("Data/assets", "/\.svg$/") as $a){
    $s = file_get_contents($a);
    echo "replace : $a \n";
    // remove in style
    $mark = false;
    $s = preg_replace_callback("/(fill|stroke)\s*:\s*([^;\"]+)(;|\"|$)/", function($m)use(& $mark){
        if (strpos($m[0], "fill:none")===0){
            return $m[0];
        }
     
        if (strpos($m[0], "stroke")===0){
            $mark = true; 
            return '';
        }
        return "";
    }, $s);

  

    // remove in attribute 
    //$s = preg_replace("/(fill|stroke)\s*=\"\s*([^\"]+)\"/", "", $s);
    $s = preg_replace_callback("/(fill|stroke)\s*=\"\s*([^\"]+)\"/", function($m)use(& $mark){
       
        if ($m[0]=='fill="none"'){
            return $m[0];
        }
        // if ($m[0]=='stroke="currentColor"'){
        //     $mark = true;     
        //     return $m[0];
        // }
        if (strpos($m[0], "stroke")===0){
            $mark = true;          
        }
       
        return "";
    }, $s);

    if ($mark){
        $s = str_replace("<svg ", "<svg stroke=\"currentColor\" ",$s);
    }
    
    file_put_contents($a, $s);

}
