<?php

///<summary>initialize controller module</summary>
class InitController{

}
