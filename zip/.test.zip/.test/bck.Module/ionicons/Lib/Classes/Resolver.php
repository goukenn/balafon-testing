<?php
namespace ionicons;

class Resolver{
    private $doc;
    private $path;
    public function __construct($doc, $path){
        $this->doc = $doc;
        $this->path = $path;
    }
    public function resolve($name) : ?callable{
        foreach(["",".svg"] as $t){
            if (file_exists($file = implode(DIRECTORY_SEPARATOR, [$this->path, $name.$t]))){
                igk_svg_register($this->doc, $rname = igk_io_basenamewithoutext($file), $file);
                igk_svg_bind_name($rname, __NAMESPACE__);
                return function(){ 
                    return true;
                };
            } 
        }
        return null;
    }
}