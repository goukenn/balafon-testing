<?php

// in order to use tiny mspa

define ("TINY_MCE",  realpath(dirname(__FILE__)."/Lib/tiny_mce/tinymce.min.js"));

function tiny_initdoc($doc){
	
	// init lib on global script
	$tinymce = TINY_MCE;
	// igk_wln_e("path to tiny : ".$tinymce);
	if (file_exists($tinymce))
		igk_doc_add_lib_script($doc, $tinymce, 'glo', false);
}

if (igk_is_ajx_demand()){
	igk_create_node("script")->setAttribute("src",TINY_MCE)->renderAJX(); 
}