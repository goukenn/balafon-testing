<?php 
$data = [1,2,3];
switch($data):
    case 1:
        echo($v."\n");
        break;
endswitch; 
