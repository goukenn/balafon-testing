<?php

/*
namespace igkdemos;

// $a = <<<'EOF'
// presentation : $x 
// EOF;

// $a->div()->Content = "OK";
// $___IGK_PHP_SETTER_VAR___['a']->div()->Content = "OK";
// $a->div()->Content = "OK".$x;
// $___IGK_PHP_SETTER_VAR___['a']->div()->Content = $___IGK_PHP_GETTER_VAR___[igk_express_val('"OK" . $x')];

// $a->div()->Content = ["one", $y];
//$___IGK_PHP_SETTER_VAR___['a']->div()->Content = $___IGK_PHP_GETTER_VAR___[igk_express_val('["one", $y]')];


// $a->div()->Content = (function(){ $x   = 8; return 9; })();
//$___IGK_PHP_SETTER_VAR___['a']->div()->Content  = (function(){ $x = 8; return 9; })();
// $a->div()->Content = (function(){ $x   = 8; return 9; })($y);
// $___IGK_PHP_SETTER_VAR___['a']->div()->Content  = $___IGK_PHP_GETTER_VAR___[igk_express_val('(function(){ $x = 8; return 9; })($y)')];
// $a->div()->Content = (function(){ $x   = 8; return 9; })() + $b;
// $___IGK_PHP_SETTER_VAR___['a']->div()->Content  = $___IGK_PHP_GETTER_VAR___[igk_express_val('(function(){ $x = 8; return 9; })()  + $b')];

$a = igk_create_node("div".$x);

if (true || (   $a   && $b)) 
{
$t->div()->Content = "Hello friend: ".$xjump;
$b = 99;
}
elseif ($present) 
echo "present"; 
elseif ($president) {
igk_debug(true); //)$a + 9;

$j + 50;
$x = <<<EOF
presentation du chef; 'avec pour dire
ses amis {$yyyy}
EOF;
}
elseif ($jump){
$gggg = $vvvv."Hello ";
$parent = 88;
}
else 
echo "finish";
// if (true)
// { 
//     if (false) $sample();
// $y = 8 + "kjsdf";
//     if ($gfds) return;
// $y = 7777;
// }



// switch($a){
//     case L:
//         break;
//     default:
//         break;
// }

// for($i = 0; $i<45; $i++){

// }

// while(true){

// }

// do {

// } while($b);

// foreach($tab as $k=>$v){

// }


function C(){

}
function A(){

}



foreach($k as $a=>$b){
echo "foreach loop";
}
for($i=0; $i < 80; $i++){
echo "for loop";
}
while($i>10){
echo "while loop";
}
*/
// switch ($variable){
//     // case 'value':
//     //     echo "switch value";
//     //     if ($c === 45){
//     //         echo "info";
//     //     }
//     // break;
//     default:
//         echo "not data";
//     break;
// }

// if (true){
//     $t->div()->Content = "Hello";

//     $t->loop($data)->div()->content = "INFO";
// }

// <div>Hello</div>

if (true){
    $t->div()->Content = $ctrl->getUser()->display().": Sample";
} else {
    $t->div()->Content = "User not found";
}