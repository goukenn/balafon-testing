<?php
$yyyy = 8985;
echo eval('return <<<EOF
presentation du chef; \' avec pour dire
ses amis {$yyyy}
EOF;');

echo "\ndone\n";
$variable = "8";
switch ($variable):
    case 'value':
        echo "switch value";
        if ($c === 45){
            echo "info";
        }
    break;
    default:
        echo "not data";
break;
endswitch;
