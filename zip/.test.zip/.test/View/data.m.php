<?php

use MyPresentatation;
use sample;
use indigo;


$t->div()->Content = "OK";