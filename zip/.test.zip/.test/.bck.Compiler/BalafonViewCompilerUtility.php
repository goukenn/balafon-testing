<?php
// @author: C.A.D. BONDJE DOUE
// @file: BalafonViewCompilerUtility.php
// @date: 20221011 11:59:17
namespace IGK\System\Runtime\Compiler;

use IGK\Controllers\SysDbController;
use IGK\System\Exceptions\ArgumentTypeNotValidException;
use IGK\System\Exceptions\EnvironmentArrayException;
use IGK\System\IO\StringBuilder;
use IGK\System\Runtime\Compiler\Html\CompilerNodeModifyDetector;
use IGK\System\Runtime\Compiler\ReadBlockInstructionInfo;
use IGK\System\ViewEnvironmentArgs;
use IGKException;
use ReflectionException;
// define token constant
defined('T_FN') || define('T_FN', "1001");
///<summary></summary>
/**
 * 
 * @package IGK\System\Runtime\Compiler
 */
abstract class BalafonViewCompilerUtility
{
    // + | ----------------------------------------------------------------------------------
    // + | reading flags
    // + |
    const VAR_READ = "VAR_READ";
    const CHANGE_BUFFER = "CHANGE_BUFFER";
    const RESTORE_BUFFER = "RESTORE_BUFFER";
    const USE_READ = 'READ_USE';
    const NS_READ = 'NS_READ';
    const READ_STRUCT = 'STRUCT_READ';

    // + | ----------------------------------------------------------------------------------
    // + | operator lists
    const VAR_OPERATOR = '.,+,-,--,++,|,||,*,/,%,&,&&,^,==,===,!=,!===,~,as,instanceof,=>';

    /**
     * check block block modification
     * @param string $source 
     * @param null|ViewEnvironmentArgs $args 
     * @param bool $checkBuffer 
     * @return bool 
     * @throws EnvironmentArrayException 
     */
    public static function CheckBlockModify(string $source, ?ViewEnvironmentArgs $args = null, bool $checkBuffer = false): bool
    {
        if (is_null($args)) {
            $args = new ViewEnvironmentArgs;
            $args->ctrl = SysDbController::ctrl();
            $args->t = igk_create_node('div');
            $args->t["class"] = "ckeck-block";
        }
        CompilerNodeModifyDetector::Init();
        $t = new CompilerNodeModifyDetector();
        if (strpos($source, "<?php") !== 0) {
            $source = "<?php\n" . $source;
        }
        $args->t = $t;
        $buffer = self::EvalSourceArgs($source, $args);
        $g = CompilerNodeModifyDetector::SysModify() || ($checkBuffer && !empty($buffer));
        CompilerNodeModifyDetector::UnInit();
        return $g;
    }
    /**
     * evaluate source args
     * @param string $source 
     * @param null|ViewEnvironmentArgs $args 
     * @param null|array $variables 
     * @return mixed 
     * @throws EnvironmentArrayException 
     */
    public static function EvalSourceArgs(string $source, ?ViewEnvironmentArgs $args = null, ?array &$variables = null)
    {
        if (is_null($args)) {
            $args = new ViewEnvironmentArgs;
        }
        require_once __DIR__ . '/helper-functions.php';
        $std_variable = new \stdClass();
        $std_variable->variables = $variables ?? [];
        igk_environment()->push(ViewEnvironmentArgs::class . "/compiler_args", $args);
        igk_environment()->push(ViewEnvironmentArgs::class . "/compiler_variables", $std_variable);
        $fc = \Closure::fromCallable(function () {
            ob_start();
            extract(func_get_arg(1));
            foreach (igk_environment()->peek(ViewEnvironmentArgs::class . "/compiler_variables")->variables as $k => $v) {
                if (isset($$k)) continue;
                $$k = &igk_environment()->peek(ViewEnvironmentArgs::class . "/compiler_variables")->variables[$k];
            }
            eval("?>" . func_get_arg(0));
            $c = ob_get_contents();
            ob_end_clean();
            return $c;
        })->bindTo($args->ctrl);
        $o = $fc($source, (array)$args);
        igk_environment()->pop(ViewEnvironmentArgs::class . "/compiler_args");
        igk_environment()->pop(ViewEnvironmentArgs::class . "/compiler_variables");
        return $o;
    }


    /**
     * php code source instruction list info list
     * @param string $code php code instruction
     * @param bool $root root code block
     * @param ?IBalafonViewCompiler $compiler
     * @return bool|array 
     */
    public static function GetInstructionsList(string $code, $root = true, ?IBalafonViewCompiler $compiler = null)
    {
        $v_tab = [];
        if (strpos($code, "<?php") !== 0) {
            $code = "<?php\n" . $code;
        }
        $v_with = false;

        $ctab = token_get_all($code);
        $lvalue = "";
        $ltoken = null;
        $options = new ReadBlockOptions();
        if ($compiler) {
            $options->compiler = $compiler;
        }
        $flag = &$options->flag;
        $v_buffer = &$options->buffer;

        // use to detected whe an expression is after an equal = in block definition
        $affectableBuffer  = &$options->affectBuffer; // null;
        $affectedFlag =  &$options->affectFlag;
        $affectInfo =  &$options->affectInfo;
     

        while (!$options->stopOn && (count($ctab) > 0)) {
            $value = array_shift($ctab);
            $id = null;
            if (is_array($value)) {
                $id = $value[0];
                $value = $value[1];
            }
            igk_debug_wln("token:" . ($id ? token_name($id) : "::") . ":" . $value);

            if (!$affectedFlag && ($value == "=")) {
                $affectedFlag = true;
                $affectableBuffer = "";
                $affectInfo = (object)[
                    "depth" => 0,
                    "space" => 0,
                    "readVarFlag" => 0,
                    "readVarName" => null,
                    "concat" => 0,
                    "dependOn" => [], 
                    "backupBuffer"=> & $v_buffer, // backup current buffer
                    "expressBuffer"=>"",
                ];
                // if ($options->blockInfo){
                //     $affectInfo->backupBuffer = & $options->blockInfo->code;
                // }
                // change current buffer to express
                $v_buffer = & $affectInfo->expressBuffer;
            } else if ($affectedFlag) {
                // + | wait til end instruction ";"
                $g = trim($value);
                if ($affectInfo->readVarFlag) {
                    $name = $affectInfo->readVarFlag["name"];
                    if (!empty($g)) {
                        if (in_array($g, explode(",", "+,-,*,/,++,--,^,~,??,||,&,&&"))) {
                            // $affectableBuffer .= "->getValue('" . $name . "')";
                            // igk_wln_e(__FILE__.":".__LINE__, "operator is $g \\ ".$affectableBuffer);
                        } else {
                            // $affectableBuffer .= "['" . $name . "']";
                        }
                        $affectInfo->readVarFlag = null;
                        // igk_wln_e(__FILE__.":".__LINE__, "not found $g \\ ".$affectableBuffer);
                    }
                }
                // else if (!empty($g)) {
                //     if (in_array($g, explode(",", "+"))) {
                //         $op_start = 1;
                //     }
                // }
                switch ($id) {
                    case T_VARIABLE:
                        $name = substr($value, 1);
                        if ($compiler) {
                            if (!isset($compiler->variables[$name])) {
                                $compiler->variables[$name] = null;
                            }
                        }
                        $affectInfo->dependOn[$name] = null;
                        $value = '$' . $name; //ViewExpressionArgHelper::GETTER_VAR;
                        $affectInfo->readVarFlag = ["name" => $name];
                        // igk_wln_e(__FILE__.":".__LINE__, "detect variable in affected expression");
                        break;
                    // case T_FUNCTION:
                    //     igk_wln_e(__FILE__ . ":" . __LINE__, "detect function in setting info");
                    //     break;
                    case T_FN:
                        igk_wln_e(__FILE__ . ":" . __LINE__, "detect function in setting info");
                        break;
                    case T_FUNC_C:
                        igk_wln_e(__FILE__ . ":" . __LINE__, "detect function in setting info");
                        break;
                    case T_DOLLAR_OPEN_CURLY_BRACES:
                        $affectInfo->depth++;
                        break;
                    case T_CURLY_OPEN:
                        $affectInfo->depth++;
                        break;
                }
                if ($id != T_WHITESPACE) {
                    if ($affectInfo->space)
                        $affectableBuffer .= ' ';
                    if (strpos("})]", $value) !== false) {
                        $affectableBuffer =  rtrim($affectableBuffer);
                    }
                    $affectableBuffer .= $value;
                    $affectInfo->space = 0;
                } else {
                    !empty($affectableBuffer) && ($affectInfo->space = 1);
                }
                if ($value == ".") {
                    //start contact
                    if ($affectInfo->readVarFlag) {
                        // after read var direct contact
                        $affectableBuffer .= '["' . $affectInfo->readVarName . '"]';
                        $affectInfo->readVarFlag = null;
                    }
                    $affectInfo->concat = 1;
                } else {
                    $affectInfo->concat = 0;
                }
                switch ($value) {
                    case "{":
                    case "[":
                    case "(":
                        if ($id != T_CURLY_OPEN)
                            $affectInfo->depth++;
                        break;
                    case "}":
                    case ")":
                    case "]":
                        $affectInfo->depth--;
                    default:
                        if (($value == ";")){                          
                            $affectableBuffer = rtrim(substr($affectableBuffer, 0, -1));
                            if ($affectInfo->dependOn) {
                                $affectableBuffer = "\$___IGK_PHP_EXPRESSION___[igk_express_eval(" . escapeshellarg($affectableBuffer) . ", " .
                                    var_export($affectInfo->dependOn, true) .
                                    ")]";
                            } else {
                                $v_buffer .= $affectableBuffer;
                            }
                            // igk_debug_wln(__FILE__.":".__LINE__,  "affected .... ", $v_buffer);
                            $affectInfo->backupBuffer = rtrim($affectInfo->backupBuffer);
                            $v_buffer = & $affectInfo->backupBuffer;

                            if ($options->blockInfo){
                                // $v_buffer .= $options->blockInfo->to_compile_code_buffer;
                                $affectableBuffer = rtrim($affectableBuffer,';');
                                $v_empty = "";
                                // igk_wln_e('the affectable ...', $affectableBuffer);
                                // update block info
                                // self::_InstructAppendBuffering()
                                self::_InstructAppendInstruct($v_empty, $v_tab, $affectableBuffer, $v_with, $options);
                                unset($v_empty);
                                // self::_InstructAppendInstruct($v_empty, $v_tab, ";", $v_with, $options);
                                
                            // igk_wln_e(__FILE__ . ":" . __LINE__, "update", 
                            //     $affectableBuffer);
                            } else {
                                // $v_buffer .= $affectInfo->expressBuffer;
                                $v_buffer .= $affectableBuffer;
                                // igk_wln_e(__FILE__.":".__LINE__, "non profit:",
                                // $affectableBuffer,
                                // "buffer:",
                                // $v_buffer,
                                // "info:",
                                // $affectInfo
                                // );
                            }

                            // igk_wln_e(__FILE__ . ":" . __LINE__,
                            //  "at end:", $v_buffer, "expression : ", 
                            //     $options->expressionBuffer,
                            // "source:", $affectInfo->backupBuffer, $options->blockInfo);
                            $affectableBuffer = "";
                            $affectedFlag = false;
                            $affectInfo = null;
                        }
                        break;
                }
                if ($affectedFlag) {
                    self::_UpdateToken($value, $id,  $ltoken, $lvalue);
                    continue;
                }
            }

            if ($flag) {
                // + | flag management 
                if ($flag == self::READ_STRUCT) {
                    $foptions = $options->flagOption;
                    $foptions->buffer .= $value;
                    switch ($id) {
                        case T_STRING:
                            if (empty($foptions->name)) {
                                $foptions->name = $value;
                            }
                            break;
                        default:
                            switch ($value) {
                                case '{':
                                    $foptions->depth++;
                                    break;
                                case '}':
                                    $foptions->depth--;
                                    if ($foptions->depth == 0) {
                                        if ($foptions->blockInfo) {
                                            $foptions->blockInfo->structs[$foptions->type][] = $foptions;
                                        } else {
                                            $options->structs[$foptions->type][] = $foptions;
                                        }
                                        $flag = null;
                                        $options->flagOption = null;
                                    }
                                    break;
                            }
                    }
                    continue;
                }

                //checking for value buffer
                if ($flag == self::CHANGE_BUFFER) {
                    $v_buffer = &$options->expressionBuffer;
                    $options->buffering = true;
                    $flag = null;
                }
                // restore buffer
                if ($flag == self::RESTORE_BUFFER) {
                    $v_buffer = &$options->buffer;
                    $options->buffering = null;
                    $flag = null;
                    
                }
                if ($flag == self::NS_READ) {
                    switch ($id) {
                        case T_NAME_QUALIFIED:
                        case T_STRING:
                            $options->namespace = $value;
                            break;
                        default:
                            switch ($value) {
                                case ";":
                                    // $v_tab[] = (object)["value" => sprintf("namespace %s;", $options->namespace)];
                                    $flag = null;
                                    break;
                                case "{":
                                    $options->blockInfo = new ReadBlockInstructionInfo("namespace");
                                    $options->blockInfo->depth  = $options->depth;
                                    $options->blocks[] = $options->blockInfo;
                                    $flag = null;
                                    break;
                            }
                    }
                    continue;
                }

                if ($flag == self::USE_READ) {
                    switch ($id) {
                        case T_NAME_QUALIFIED:
                        case T_NAME_FULLY_QUALIFIED:
                            $options->uses[$value] = $value;
                            $options->flagOption = ["name" => $value, "alias" => false];
                            break;
                        case T_AS:
                            $options->flagOption["alias"] = true;
                            break;
                        case T_FUNCTION:
                            $options->flagOption = ["type"=> "function", "alias"=>false];
                            break;
                        case T_STRING:
                            // igk_wln_e(__FILE__.":".__LINE__,  "the name options", $value, $options->flagOption);
                            if (igk_getv($options->flagOption, "type")=='function'){
                                if ($options->flagOption["alias"]){
                                    $v_name = $options->flagOption["name"];
                                    $options->uses[$v_name] = $value;
                                }else {
                                    $name = "function ".$value;
                                    $options->uses[$name] = $name;
                                    $options->flagOption["name"] = $name;
                                }
                            }else if ($options->flagOption["alias"]){
                                $v_name = $options->flagOption["name"];
                                $options->uses[$v_name] = $value;
                                $options->flagOption[$name] = $value;
                            }
                            break;
                        default:
                            switch ($value) {
                                case ';':
                                    // igk_wln_e(__FILE__.":".__LINE__, $options->uses);
                                    $options->flagOption = null;
                                    $flag = null;
                                    break;
                            }
                    }
                    continue;
                }

                if ($flag == self::VAR_READ) {
                    $append_value = false;
                    $add_express = ($id == T_ENCAPSED_AND_WHITESPACE) || ('"' == $value);
                    // igk_wln_e("var read ... ", $add_express, $id, $value);
                    if ($add_express) {
                        $flag = null;
                        $x = sprintf('%s', $options->flagOption->express);
                        self::_InstructAppendInstruct($v_buffer, $v_tab, $x, $v_with, $options);
                        $options->flagOption = null;
                        $append_value = true;
                    } else {
                        switch ($value) {
                            case "=":
                            case "(":
                            case "->":
                            case "[":
                                // leave the value write context
                                $flag = null;
                                // $v_x = sprintf('$%s%s', $options->flagOption->name,
                                // $value==='='? ' ': "");
                                // + | stransform to setter expression
                                $v_x = sprintf(
                                    '$%s[\'%s\']%s',
                                    ViewExpressionArgHelper::SETTER_VAR,
                                    $options->flagOption->name,
                                    $value === '=' ? ' ' : ""
                                );
                                if ($value == '=') {
                                    // append variable name to export in global context
                                    $v_x = rtrim($v_x) . " = $" . $options->flagOption->name . " ";
                                }
                                self::_InstructAppendInstruct($v_buffer, $v_tab, $v_x, $v_with, $options);
                                $options->flagOption = null;
                                $append_value = true;
                                break;
                            case ".":
                                $flag = null;
                                $x = sprintf('%s', $options->flagOption->express);
                                self::_InstructAppendInstruct($v_buffer, $v_tab, $x, $v_with, $options);
                                $options->flagOption = null;
                                $append_value = true;
                                break;
                            case "?":
                            case ":":
                            case ";":
                            case "++":
                            case "--":
                            case "+":
                            case "%":
                            case ")":
                                $flag = null;
                                $x = "";
                                // igk_debug_wln("concat: ?????????\n", $options->flagOption);
                                if ($options->flagOption->contact) {
                                    $x = sprintf('%s', $options->flagOption->express);
                                } else {
                                    // igk_wln_e(__FILE__.":".__LINE__,  "last ..... ",$options->flagOption, $ltoken);
                                    // $x = sprintf('%s', $options->flagOption->encapsed_express);
                                    $x = sprintf('$%s', $options->flagOption->name);
                                }
                                self::_InstructAppendInstruct($v_buffer, $v_tab, $x, $v_with, $options);
                                $options->flagOption = null;
                                $append_value = true;
                                break;
                            default:
                                if ($id != T_WHITESPACE) {
                                    $options->flagOption->space = 0;
                                    $flag = null;
                                    $x = sprintf('$%s."name"', $options->flagOption->name);
                                    self::_InstructAppendInstruct($v_buffer, $v_tab, $x, $v_with, $options);
                                    $options->flagOption = null;
                                    $append_value = true;
                                }
                                break;
                        }
                    }
                    if ($append_value) {
                        self::_InstructAppendInstruct($v_buffer, $v_tab, $value, $v_with, $options);
                    }
                    continue;
                }
            }
            self::_InstructionListNextRequestHandle($options, $value, $v_buffer);

            switch ($id) {
                case T_NAMESPACE:
                    if (!empty($options->namespace))
                        return false;
                    $options->namespace = true;
                    $flag = self::NS_READ;
                    break;
                case T_USE:
                    if ((!$options->blockInfo) && ($options->depth == 0)) {
                        $flag = self::USE_READ;
                        empty($options->uses) && $options->uses = [];
                        $options->flagOption= [];
                    }
                    break;
                case T_COMMENT:
                    if (($options->depth === 0) || $options->blockInfo) {
                        if (preg_match("/%\s*{\{(?P<expression>.+)\}\}/", $value, $data)) {
                            if ($data = $options->compiler->evaluationComment(trim($data['expression']))) {
                                $c = new ReadBlockResult($data, ReadBlockResult::COMPILED);
                                if ($options->blockInfo) {
                                    $options->blockInfo->codeBlocks[] = $c;
                                } else {
                                    $v_tab[] = $c;
                                }
                            }
                        }
                    }
                    break;
                case T_DOC_COMMENT:
                    $options->docComments[] = $value;
                    break;
                case T_CLASS:
                case T_INTERFACE;
                case T_TRAIT:
                    $flag = self::READ_STRUCT;
                    $options->flagOption = new ReadStructInfo($value);
                    $options->flagOption->modifiers = $options->modifiers;
                    $options->flagOption->blockInfo = $options->blockInfo;
                    $options->modifiers = [];
                    break;
                case T_ABSTRACT:
                case T_PRIVATE:
                case T_PROTECTED:
                case T_FINAL:
                case T_PUBLIC:
                    // modifier
                    $options->modifiers[] = $value;
                    break;
                case T_SWITCH:
                case T_FOR:
                case T_TRY:
                case T_FOREACH:
                case T_WHILE:
                case T_IF:
                case T_ELSE:
                case T_ELSEIF:
                    self::_InstructCompileBlock($options, $compiler);
                    // start with try/instruction
                    self::_InstructAppendInstruct($v_buffer, $v_tab, $value, $v_with, $options);
                    $options->blockInfo = new ReadBlockInstructionInfo($value);
                    $options->blockInfo->depth  = $options->depth;
                    $options->blocks[] = $options->blockInfo;
                    if ($options->modifiers) {
                        $options->modifiers = [];
                    }
                    break;
                case T_CATCH:
                case T_FINALLY:
                case T_FUNCTION:
                case T_FUNC_C:
                    if ($root && empty(trim($v_buffer))) {
                        return false;
                    }
                    self::_InstructAppendInstruct($v_buffer, $v_tab, $value, $v_with, $options);
                    $options->blockInfo = new ReadBlockInstructionInfo($value);
                    $options->blockInfo->depth = $options->depth;
                    $options->blocks[] = $options->blockInfo;
                    if ($options->modifiers) {
                        $options->blockInfo->modifiers = $options->modifiers;
                        $options->modifiers = [];
                    }
                    break;
                case T_STRING:
                    $binfo = $options->blockInfo;
                    self::_InstructDetectExit($value, $id, $options);                   
                    if ($binfo) {
                        if ($binfo->nameSupport) {
                            $binfo->name = $value;
                            $binfo->nameSupport = null;
                        }
                    }
                    self::_InstructAppendInstruct($v_buffer, $v_tab, $value, $v_with, $options);
                    break;
                case T_OPEN_TAG:
                    if ($v_with) {
                        self::_InstructAppendInstruct($v_buffer, $v_tab, $value, $v_with, $options);
                    }
                    $v_with = true;
                    break;
                case T_VARIABLE:
                    $name = substr($value, 1);
                    if ($compiler) {
                        if (!isset($compiler->variables[$name])) {
                            $compiler->variables[$name] = null;
                        }
                    }
                    $blf = $options->blockInfo;
                    if (!$blf || !$blf->isReadingCondition()) {

                        $_bracket = (!$lvalue != '.') && (($lvalue == '"') || in_array($ltoken, [T_ENCAPSED_AND_WHITESPACE]));
                        if ($_bracket || ($ltoken == T_CURLY_OPEN)) {
                            $value = "\$___IGK_PHP_EXPRESS_VAR___('" . $name . "')";
                            if ($_bracket) {
                                $value = sprintf('{%s}', $value);
                            }
                        } else {
                            if (!empty($options->expressions)) {
                                $options->expressions[0]->detectVars[$name] = $options->flagOption;
                            } else {
                                $options->flag = self::VAR_READ;
                                $options->flagOption = (object)[
                                    "name" => $name,
                                    "express" => "igk_express_var('" . $name . "')",
                                    "encapsed_express" => "\$___IGK_PHP_EXPRESS_VAR___('" . $name . "')",
                                    "contact" => in_array($lvalue, explode(',', self::VAR_OPERATOR)),
                                    "space" => false
                                ];
                                // igk_wln_e("the var: ",$value, $options->flagOption);
                                $value = "";
                            }
                        }
                    }
                    self::_InstructAppendInstruct($v_buffer, $v_tab, $value, $v_with, $options);
                    break;
                case T_BREAK:
                case T_CONTINUE:
                default:
                    self::_InstructDetectExit($value, $id, $options);  
                    self::_InstructAppendInstruct($v_buffer, $v_tab, $value, $v_with, $options);
                    if ($options->stopOnReturn && ($options->depth==0) && $value==';'){
                        $options->stopOn = true;  
                    }
                    break;
            }
            // last real value 
            self::_UpdateToken($value, $id,  $ltoken, $lvalue);
        }

        if (!empty($g  = trim($v_buffer))) {
            if (preg_match("/[\};]$/", $g)) {
                if ($options->nextRequest) {
                    $v_buffer = rtrim($v_buffer) . ";";
                    $options->nextRequest = null;
                }
                // self::_InstructionListNextRequestHandle($options, $g);
                $v_tab[] = (object)["value" => trim($v_buffer)];
                $v_buffer = "";
            } else {
                error_log("possibility of missing data");
                igk_wln_e(__FILE__ . ":" . __LINE__, "error: possibility of missing data : $lvalue \ntoken: $ltoken : " . token_name($ltoken) . "\nBuffer:" . $v_buffer);
            }
        }

        if ($compiler) {
            $source = self::_GenerateSourceCode($options, $v_tab, $compiler);
            $compiler->append($source);
            if (empty($v_tab)){
                $v_tab[] = ["value"=>$source];
            }
            // igk_wln_e(__FILE__.":".__LINE__, "source code....", $source);
        }
        return $v_tab;
    }
    private static function _InstructDetectExit($value, $id, ReadBlockOptions $options){
        if ((T_EXIT == $id) || ((T_STRING==$id) && (($value == "igk_exit") || ($value == 'igk_do_response')))) {
            !is_array($options->exitDetected) && $options->exitDetected = [];
            $options->exitDetected[$value] = $value;
        }
        if (($id == T_RETURN)&&($options->depth==0)){
            $options->stopOnReturn = true; 
        }
    }
    private static function _UpdateToken($value, $id, &$ltoken, &$lvalue)
    {
        if (!empty(trim($value)))
            $lvalue = $value;
        if ($id)
            $ltoken = $id;
    }
    /**
     * gerete compilations sources code 
     * @param mixed $options 
     * @param mixed $tab 
     * @param mixed $compiler 
     * @return string 
     * @throws IGKException 
     */
    private static function _GenerateSourceCode( ReadBlockOptions $options, $tab, $compiler): string
    {

        $header = new StringBuilder;
        $header->append("<?php");
        $cheader = new StringBuilder;
        if ($options->namespace) {
            $header->appendLine("");
            $header->appendLine(sprintf("namespace %s;\n", $options->namespace));
        }
        if ($options->uses) {
            $header->appendLine("");
            ksort($options->uses);
            foreach ($options->uses as $use => $alias) {
                $header->appendLine(sprintf("use %s;", $use == $alias ? $use : $use . " as " . $alias));
            }
            $header->appendLine("");
        }
        $cheader->appendLine($header . "");
        if ($structs = $options->structs) {
            foreach (["interface", "trait", "class"] as $m) {
                if (is_null($def = igk_getv($structs, $m))) {
                    continue;
                }
                ksort($def);
                foreach ($def as $tm) {
                    $mod = trim(implode(" ", $tm->modifiers));
                    $header->appendLine(sprintf("%s", $mod . $tm->type . $tm->buffer) . "\n");

                    // because class can't be decalared for multiple evaluation need to protect
                    switch ($tm->type) {
                        case "class":
                            $cheader->appendLine(sprintf("if (!class_exists(%s::class)){\n%s }", $tm->name, $mod . $tm->type . $tm->buffer) . "\n");
                            break;
                        case "interface":
                            $cheader->appendLine(sprintf("if (!interface_exists(%s::class)){\n%s }", $tm->name, $mod . $tm->type . $tm->buffer) . "\n");
                            break;
                        case "trait":
                            $cheader->appendLine(sprintf("if (!trait_exists(%s::class)){\n%s }", $tm->name, $mod . $tm->type . $tm->buffer) . "\n");
                            break;
                    }
                }
            }
        }

        if ($g = $compiler->compile($tab, true, $cheader . "")){
            // + | remove join compiled data
            $g = ltrim(ltrim($g, "?><?php"));
        }
        return implode("\n", [$header, $g]);
    }

    /**
     * 
     * @param mixed $v_instruction 
     * @param mixed $v_tab 
     * @param mixed $value 
     * @param mixed $v_with 
     * @param ReadBlockOptions $options 
     * @return void 
     * @throws IGKException 
     * @throws ArgumentTypeNotValidException 
     * @throws ReflectionException 
     */
    private static function _InstructAppendInstruct(&$v_instruction, &$v_tab, $value, $v_with, ReadBlockOptions $options)
    {
        if ($v_with) {
            $v_instruction .= $value;
            $blockinfo = $options->blockInfo;
            if ($blockinfo) {
                if ($blockinfo->canAppendCode()) {
                    $is_empty = empty(trim($value));
                    if (!empty($blockinfo->code) || !$is_empty) {
                        if ($blockinfo->skipWhiteSpace && $is_empty){
                            $value = "";
                        }else if ($is_empty){
                            $blockinfo->skipWhiteSpace = 1; 
                        }else {
                            $blockinfo->skipWhiteSpace = 0;
                        }

                        $blockinfo->code .= $value;
                        if (!$options->buffering) {
                            $blockinfo->to_compile_code_buffer .= $value;
                        } else {
                            // igk_debug_wln("--------------------------------------add to buffer list ......");
                            $options->bufferLists["block_info_buffer_list"] = &$blockinfo->to_compile_code_buffer;
                        }
                    }
                } else {
                    if (!$blockinfo->nameSupport && $blockinfo->endConditionFlag) {
                        if (!empty($blockinfo->condition) || !empty(trim($value)))
                            $blockinfo->condition .= $value;
                    }
                }
            }

            switch ($value) {
                case ";":
                    self::_InstructionAddCodeBlock($options, $v_tab, $v_instruction);
                    break;
                case '(':
                    $options->expressionConditionDepth++;
                    if ($blf = $options->blockInfo) {
                        // end name reading if name support
                        if ($blf->nameSupport) {
                            $blf->nameSupport = false;
                        }
                        // mark condition/argument read read start -                        
                        if ($blf->endConditionFlag && is_null($blf->endConditionDepth)) {
                            $blf->endConditionDepth = $options->expressionConditionDepth - 1;
                        }
                        // check if still reading condition
                        if ($blf->isReadingCondition()) {
                            break;
                        }
                    }
                    if ($options->expressionConditionDepth == 1) {
                        $exblock = new ReadBlockExpressionInfo;
                        $options->expressionBuffer = &$exblock->buffer;
                        $options->expressionBuffer = $value;
                        $options->flag = self::CHANGE_BUFFER;
                        $options->expressions[] = $exblock;
                    }
                    break;
                case ')':
                    $options->expressionConditionDepth--;
                    if ($blf = $options->blockInfo) {
                        if ($blf->endConditionFlag) {
                            if ($blf->endConditionDepth ==  $options->expressionConditionDepth) {
                                $blf->endConditionFlag = false;
                            }
                            // igk_debug_wln(__FILE__.":".__LINE__, "---------------close but continue read condition : ?[".
                            // $blf->endConditionFlag
                            // ."] ");
                            break;
                        }
                    }
                    // igk_wln_e("finisht---------------close but continue read condition ");
                    if ($options->expressionConditionDepth === 0) {
                        self::_InstructionEndExpresion($options);
                    }
                    break;
                case "{":
                    $options->depth++;
                    if ($blockinfo) {
                        $blockinfo->blockFlag = true;
                    }
                    break;
                case "}":
                    $options->depth--;
                    if ($options->blockInfo) {
                        if ($options->blockInfo->type == "function") {
                            // must end with }; or })(
                            if (empty($options->blockInfo->name)) {
                                $options->nextRequest = [";", ")"];
                                $options->appendNext = ";";
                            }
                        }
                        if ($options->blockInfo->depth == $options->depth) {
                            // END BLOCK READ:
                            self::_InstructionEndBlockRead($options, $v_tab);
                        }
                    }
                    break;
            }
        }
    }
    /**
     * add code block.
     * @param ReadBlockOptions $options 
     * @param array $v_tab 
     * @param string $v_instruction 
     * @return void 
     */
    private static function _InstructionAddCodeBlock(ReadBlockOptions $options, &$v_tab, &$v_instruction)
    {
        $g = trim($v_instruction);
        // igk_wln_e(
        //     __FILE__ . ":" . __LINE__,
        //     "------------------add instruction block",
        //     $g,
        //     "to compile ",
        //     $options->blockInfo->to_compile_code_buffer,
        //     "data:",
        //     $options->blockInfo
        // );
        if (!empty($g)) {
            if (!$options->blockInfo) {
                $v_block = new ReadBlockResult($g, 1); // (object)["value" => $g];
                $v_tab[] = $v_block;
                $v_instruction = "";
            } else {
                $g = ltrim($options->blockInfo->to_compile_code_buffer ?? "", "{");
                $g = rtrim($g, "}");
                if (!empty($g = trim($g))) {
                    $v_block = new ReadBlockResult($g, 2); // (object)["value" => $g];
                    $options->blockInfo->codeBlocks[] = $v_block;
                }
                $options->blockInfo->to_compile_code_buffer = "";
                if (!$options->blockInfo->blockFlag) {
                    //compile and end block definition
                    self::_InstructionEndBlockRead($options, $v_tab);
                }
            }
        }
    }
    /**
     * check for next request expectation
     * @param ReadBlockOptions $options 
     * @param mixed $value 
     * @param string $v_instruction 
     * @return void 
     * @throws IGKException 
     * @throws ArgumentTypeNotValidException 
     * @throws ReflectionException 
     */
    private static function _InstructionListNextRequestHandle(ReadBlockOptions $options, $value, string &$v_instruction)
    {
        if ($options->nextRequest && !empty($c = trim($value))) {
            if (!in_array($c, $options->nextRequest)) {
                if ($options->appendNext) {
                    $v_instruction = rtrim($v_instruction) . $options->appendNext;
                    $options->appendNext = null;
                } else {
                    igk_die(sprintf(
                        "expected '%s' but %s found.",
                        implode("' or '", $options->nextRequest),
                        $value
                    ));
                }
            }
            $options->nextRequest = null;
        }
    }
    private static function _InstructionEndBlockRead(ReadBlockOptions $options, &$v_tab)
    {
        // igk_debug_wln("-------------------------------------instruct end block read");
        $blockinfo = array_pop($options->blocks);
        if ($blockinfo) {
            // igk_wln_e(__FILE__.":".__LINE__,  $blockinfo, count($options->blocks));
            if (($c = count($options->blocks)) === 0) {
                $v_tab[] = $blockinfo;
                $options->blockInfo = null;  
                // igk_wln_e(__FILE__.":".__LINE__, "------------------- end block ", $v_tab[2] === $blockinfo, $options, "count:". igk_env_count(__FUNCTION__));
            } else {

                $options->blockInfo = $options->blocks[$c - 1];
                $options->blockInfo->codeBlocks = $blockinfo;
                // igk_wln_e(__FILE__ . ":" . __LINE__,  "done passing to parent block", $options->blockInfo->codeBlocks);
            }
        }
        // $blockinfo = array_pop($options->blocks);
        // $compiler = $options->compiler;
        // $compile_result = "";
        // if ($blockinfo) {
        //     self::_InstructCompileBlock($options);
        //     $compile_result = $blockinfo->compile_result;
        // }
        // if (($c = count($options->blocks)) > 0) {
        //     $options->blockInfo = $options->blocks[$c - 1];
        //     $options->blockInfo->compile_result .= $compile_result;
        // } else {
        //     if ($blockinfo) {
        //         if (!empty($result = $blockinfo->compile())) {
        //             $compiler && $compiler->append($result);
        //         }
        //     }
        //     $options->blockInfo = null;
        // }
    }
    /**
     * compile block
     * @param ReadBlockOptions $options 
     * @return void 
     * @throws IGKException 
     * @throws ArgumentTypeNotValidException 
     * @throws ReflectionException 
     */
    private static function _InstructCompileBlock(ReadBlockOptions $options)
    {
        // $listener = $options->compiler;
        // if ($options->blockInfo && $listener) {
        //     $result = $listener->compile($options->blockInfo->codeBlocks);
        //     // igk_debug_wln_e(
        //     //     __FILE__.":".__LINE__, 
        //     //     "to compile: ", $options->blockInfo, 
        //     //     "result: ", 
        //     //     $result,
        //     // );
        //     $options->blockInfo->compile_result .= $result;
        //     $options->blockInfo->to_compile_code_buffer = "";
        // }
    }

    private static function _InstructionEndExpresion(ReadBlockOptions $options)
    {
        $options->flag = self::RESTORE_BUFFER;
        $exblock = array_pop($options->expressions);
        if (!empty($exblock->detectVars)) {
            // check if is method - request
            if (preg_match("/" . IGK_IDENTIFIER_PATTERN . "\s*\($/", $options->buffer)) {
                foreach (array_keys($exblock->detectVars) as $n) {

                    $exblock->buffer = str_replace('$' . $n, '$___IGK_PHP_GETTER___["' . $n . '"]', $exblock->buffer);

                    //$exblock->buffer = str_replace('$' . $n, 'igk_express_arg("' . $n . '")', $exblock->buffer);
                }
                $exblock->buffer = ltrim($exblock->buffer, "(");
                $options->buffer .=  $exblock->buffer;
                self::_InstructAppendBuffering($options, $exblock->buffer);
                unset($options->expressionBuffer); // = null;
                $options->expressionBuffer = "";
                return;
            }
            // + | variable detected in expression in expression
            foreach (array_keys($exblock->detectVars) as $n) {
                $exblock->buffer = str_replace('$' . $n, 'igk_express_var("' . $n . '")', $exblock->buffer);
            }


            $exblock->buffer = rtrim(ltrim($exblock->buffer, "("), ")");
            $tmp_buffer = "igk_express_eval('" . $exblock->buffer . "'))";
            $options->buffer .= $tmp_buffer;
            self::_InstructAppendBuffering($options, $tmp_buffer);
        } else {
            // no var detected just leave at its
            $options->buffer .= $tmp_buffer = ltrim($exblock->buffer, "(");
            self::_InstructAppendBuffering($options, $tmp_buffer);
        }

        unset($options->expressionBuffer); // = null;
        $options->expressionBuffer = "";
    }

    private static function _InstructAppendBuffering(ReadBlockOptions $options, string $buffering)
    {
        // reference important to update the buffer list with 
        foreach ($options->bufferLists as &$k) {
            $k .= $buffering;
        }
        // igk_wln_e(__FILE__.":".__LINE__, " ---------------------------------- restore buffer list ", $k, $options->bufferLists );
        $options->bufferLists = [];
    }
}
