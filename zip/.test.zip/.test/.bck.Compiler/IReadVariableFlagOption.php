<?php
// @author: C.A.D. BONDJE DOUE
// @file: IReadVariableFlagOption.php
// @date: 20221015 16:15:24
namespace IGK\System\Runtime\Compiler;


///<summary></summary>
/**
* 
* @package IGK\System\Runtime\Compiler
* @property string $name => $name,
* @property string $express => "igk_express_var('" . $name . "')",
* @property string $encapsed_express => "\$___IGK_PHP_EXPRESS_VAR___('" . $name . "')",
* @property string $contact => in_array($lvalue, explode(',', self::VAR_OPERATOR)),
* @property bool   $space => false
*/
interface IReadVariableFlagOption{    
}