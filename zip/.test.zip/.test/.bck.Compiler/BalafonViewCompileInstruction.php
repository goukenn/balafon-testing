<?php
// @author: C.A.D. BONDJE DOUE
// @file: BalafonViewCompileInstruction.php
// @date: 20221012 11:06:33
namespace IGK\System\Runtime\Compiler;

use IGK\System\Exceptions\EnvironmentArrayException;
use IGK\System\Html\HtmlRenderer;
use IGK\System\IO\StringBuilder;
use IGK\System\Runtime\Compiler\Html\CompilerNodeModifyDetector;
use IGK\System\Runtime\Compiler\ViewExpressionEval;
use IGK\System\ViewEnvironmentArgs;
use IGK\System\ViewExtractArgHelper;
use IGKException;

require_once __DIR__."/helper-functions.php";
///<summary></summary>
/**
* use to compiles instructions 
* @package IGK\System\Runtime\Compiler
*/
class BalafonViewCompileInstruction{
    /**
     * instructlist list to compile
     * @var ?array
     */
    var $instructions;
    /**
     * core variable to pass to compilation 
     * @var array
     */
    var $variables = [];
    /**
     * the ouput source code
     * @var ?string
     */
    private $m_output = "";
    /**
     * base controller 
     * @var mixed
     */
    var $controller;
    /**
     * code header 
     * @var string code
     */
    var $header;
    /**
     * extract variable
     * @var false
     */
    var $extract = false;
    
    /**
     * store header shared code source
     * @var mixed
     */
    private static $sm_SOURCE;
    /**
     * compile instruction
     * @return bool|string 
     * @throws IGKException 
     * @throws EnvironmentArrayException 
     * @remarks 0 = code source
     *  1= variables->data
     *  2= 
     */
    public function compile(){   
        if (!is_array($this->instructions)){
            return false;
        }
        $_eval = \Closure::fromCallable(function(){
            foreach(array_keys(func_get_arg(1)->data) as $_){
                if ($_=="_"){
                    igk_die("[_] is reserved variable");
                }
                if ($_=="this"){
                    // replace with ctrl
                    $_ = "ctrl";
                }
                $$_ = & func_get_arg(1)->data[$_] ;
            }
            unset($_);
            // igk_debug_wln( __FILE__.":".__LINE__, "eval:".func_get_arg(0));
            igk_ilog("eval : ".func_get_arg(0));
            ob_start();
            // echo "/* compile */";
       
            if (func_num_args()>2){
                self::$sm_SOURCE = implode("\n", [func_get_arg(2), func_get_arg(0)]);
                $___IGK_PHP_RESPONSE___ = eval("?>".self::$sm_SOURCE); 
            }else {
                $___IGK_PHP_RESPONSE___ = eval(func_get_arg(0));
            }
          
            $buffer = trim(ob_get_contents());
            // igk_debug_wln_e("first:".$buffer, "x value:", $x);
            ob_end_clean();
            if (!empty($buffer) || $t->getModify()){
                if ($t->getModify()){
                    $t->text($buffer);
                    return;
                } 
                return func_get_arg(0);                
            }
            if ($t->getParam(CompilerNodeModifyDetector::CLEAR_FLAG_PARAM)){
                $t->setParam(CompilerNodeModifyDetector::CLEAR_FLAG_PARAM, null);
                return null;
            }
            if ($___IGK_PHP_SETTER___->getIsUpdate()){
                $g = $___IGK_PHP_SETTER___->getExpression(func_get_arg(0));
                $___IGK_PHP_SETTER___->resetUpdate();
                return $g; 
            }
            return func_get_arg(0);
        })->bindTo($this->controller);
        
        $out_put = & $this->m_output;
        $sb = new StringBuilder($out_put);
        $detector = new CompilerNodeModifyDetector;
        $init = CompilerNodeModifyDetector::Init();
        $vars = & $this->variables ;
        $bck = igk_getv($vars, "t", igk_create_node('notagnode'));
        $vars["t"] = $detector; 

        $detector ->setDocument(igk_getv($vars,"doc"));
        

        // $vars["___IGK_PHP_EXPRESS_VAR___"] = "igk_express_ecapsed_string";
        $vars["___IGK_PHP_EXPRESS_VAR___"] = "igk_express_var";
        // $vars["___IGK_PHP_VAR___"] = "igk_express_litteral_var";
        $vars["___IGK_PHP_EXTRACT_VAR___"] = $this->extract;
        $vars[ViewExpressionArgHelper::SETTER_VAR] = new ViewExpressionSetter($vars);
        $vars[ViewExpressionArgHelper::GETTER_VAR] = new ViewExpressionGetter($vars);
        $vars[ViewExpressionArgHelper::EXPRESSION] = new ViewExpression($vars,$_eval, $this->extract);
        $vars[ViewExpressionArgHelper::RESPONSE] = new ViewExpression($vars,$_eval, $this->extract);

        // igk_wln_e("extract .....", $this->extract);
       
        $vars_clone = array_merge($vars);
        igk_environment()->push(ViewEnvironmentArgs::class."/compiler_args", (object)[
            "variables"=>& $vars
        ]);
        // parameters to pass to avoid populate eval context.
        $pass = (object)["data"=>& $vars];
        // block of instruction 
        $qtab = $this->instructions;
        // nodes liste 
        $nodes = [];
        // parent block instruction 
        $p = null;

        while(count($qtab)>0){
            $k = array_shift($qtab);
            // $sb->appendLine("// detect:");
            if ($k instanceof ReadBlockInstructionInfo){ 
                // igk_debug_wln(
                //     __FILE__.":".__LINE__, 
                //     "Instruction info read ");
                if ((count($nodes)>0) && ($nodes[0]=== $k)){
                    // igk_debug_wln(__FILE__.":".__LINE__,  "finish node:");
                    array_shift($nodes);
                    $p = count($nodes)>0 ? $nodes[0] : null;
                    $_compile = $k->compile();
                    $n = !empty($_compile) ? trim($_compile) : '';
                    // remove php block code...
                    if (strpos($n, "<?php")===0){
                        $n = ltrim(substr($n, 5));
                    }
                    if (($pos = strrpos($n, "?>"))!==false){
                        $n = substr($n, 0, $pos);
                    }
                    if ($p === null){
                        //render to root
                        $sb->appendLine($n);
                    } else {
                        $p->compile_result .= $n."// in";
                    }
                    continue;
                }
                array_unshift($qtab, ...array_merge($k->codeBlocks? $k->codeBlocks: [],
                [$k]));
                array_unshift($nodes, $k);
                $p = $k;
                $detector->clearChilds();
                continue;
            }  
            $n = null;           
            if (!empty($k->value)){
                $detector->setFreezeClearModify(true);
                $n = $_eval($k->value, $pass, $this->header);
                $detector->setFreezeClearModify(false);
                // in subchilds
                if ($detector->getModify()){
                    $attr = $vars["t"]->getAttributes();
                    if ($attr->count()>0){
                        $m = HtmlRenderer::GetAttributeArray($detector, null);                       
                        $n .= '//%{{_ATTRIBS_BEGIN}}'."\n";
                        $n .= '$__IGK_PHP_ATTRIBS___[]='.var_export($m, true).';';
                        $n .= 'if (isset($t)) $t->setAttributes($__IGK_PHP_ATTRIBS___[count($__IGK_PHP_ATTRIBS___)-1]);'."\n";
                        $n .= '//%{{_ATTRIBS_END}};'."\n";
                    } 
                    $n .= $vars["doc"]?->renderAccessiblity();
                    $n = $n."?>".$detector->render()."<?php";
                    $detector->clearChilds();
                }
            }

            if ($p){
                $p->compile_result .= $n."\n"; 
            } else { 
                if (!empty($n)){
                    $sb->appendLine(rtrim($n));  
                }                     
            }
        } 
        

        igk_environment()->pop(ViewEnvironmentArgs::class."/compiler_args");
        if ($init){
            CompilerNodeModifyDetector::UnInit();
        }
        if ($vars_clone === $vars){
            // if array are equals
        }
        if ($detector->getModify() && $bck){ 
            // clear detectector
            $detector->clearChilds();
        }
        // igk_trace();
        // igk_wln_e(__FILE__.":".__LINE__,  "the out .... ", $out_put);
        return $out_put;
    }
    /**
     * get the output
     * @return null|string 
     */
    public function output(){
        return $this->m_output;
    }
    
}