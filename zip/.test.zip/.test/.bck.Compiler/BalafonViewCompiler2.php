<?php
// @author: C.A.D. BONDJE DOUE
// @file: BalafonViewCompiler2.php
// @date: 20221013 14:57:44
namespace IGK\System\Runtime\Compiler;

use IGK\Controllers\BaseController;
use IGK\System\Exceptions\ArgumentTypeNotValidException;
use IGK\System\Exceptions\EnvironmentArrayException;
use IGK\System\Runtime\Compiler\Html\ConditionBlockNode;
use IGK\System\Runtime\Compiler\Html\ViewDocumentHandler;
use IGK\System\ViewEnvironmentArgs;
use IGKException;
use ReflectionException;

///<summary></summary>
/**
 * compile instruction to view html compiled result 
 * @package IGK\System\Runtime\Compiler
 */
class BalafonViewCompiler2 implements IBalafonViewCompiler
{
    /**
     * store compilation result
     * @var ?string
     */
    private $_output;
    /**
     * string
     * @var mixed
     */
    var $source;
    /**
     * 
     * @var ViewEnvironmentArgs
     */
    var $options;

    var $variables = [];

    private $m_compilerHandler;

    /**
     * .ctr
     * @return void 
     */
    public function __construct()
    {
    }

    public function output(): ?string
    {
        return $this->_output;
    }
    /**
     * extract data
     * @param array $blockInstructions 
     * @param bool $extract 
     * @return void 
     * @throws IGKException 
     * @throws EnvironmentArrayException 
     */
    public function compile(array $blockInstructions, bool $extract = true, ?string $header = null)
    {

        $v_compiler = new BalafonViewCompileInstruction;
        $v_compiler->instructions = $blockInstructions;
        $v_compiler->variables = &$this->variables;
        $v_compiler->extract = $extract;
        $v_compiler->header = $header;
        return $v_compiler->compile();
    }
    /**
     * append source result
     * @param string $src 
     * @return mixed 
     */
    public function append(string $src)
    {

        $src = rtrim($src, "?><?php\n");
        $this->_output .= $src;
    }
    protected function createCompilerHandler()
    {
        return new BalafonViewCompilerHandler($this);
    }
    /**
     * 
     * @param mixed $data 
     * @return mixed 
     * @throws IGKException 
     * @throws ArgumentTypeNotValidException 
     * @throws ReflectionException 
     */
    public function evaluationComment($data)
    {
        if (is_null($this->m_compilerHandler)) {
            $this->m_compilerHandler = $this->createCompilerHandler()
                ?? igk_die("failed to create compilation handler");
        }
        return $this->m_compilerHandler->evaluate($data);
    }


    /**
     * compile source code
     * @param string $source 
     * @return null|string 
     * @throws IGKException 
     * @throws ArgumentTypeNotValidException 
     * @throws ReflectionException 
     */
    public function compileSource(string $source): ?string
    {
        $compiler = new BalafonViewCompiler2;
        $compiler->options = $this->options;
        $compiler->variables = &$this->variables;
        if (BalafonViewCompilerUtility::GetInstructionsList($source, true, $compiler)) {
            return $compiler->_output;
        }
        return null;
    }

    /**
     * compile view file
     * @param BaseController $controller 
     * @param string $viewFile 
     * @return null|string 
     * @throws IGKException 
     * @throws ArgumentTypeNotValidException 
     * @throws ReflectionException 
     */
    public static function CompileView(BaseController $controller, string $viewFile): ?string
    {
        if (($file = $controller->getViewFile($viewFile)) && file_exists($file)) {
            $compiler = new static;
            $compiler->options = new ViewEnvironmentArgs;
            $compiler->options->ctrl = $controller;
            $compiler->options->doc = new ViewDocumentHandler;
            $src = file_get_contents($file);
            if (BalafonViewCompilerUtility::GetInstructionsList($src, true, $compiler)) {
                return $compiler->output();
            }
            igk_wln_e(__FILE__ . ":" . __LINE__, "source:", $file);
        }
        return null;
    }
}
