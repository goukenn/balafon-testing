<?php
// @author: C.A.D. BONDJE DOUE
// @file: ViewDocumentHandler.php
// @date: 20221019 09:20:46
namespace IGK\System\Runtime\Compiler\Html;

use IGK\System\Exceptions\NotImplementException;
use IGK\System\Html\Dom\HtmlNode;
use IGK\System\Html\Dom\HtmlNoTagNode;
use IGK\System\Runtime\Compiler\IViewCompilerArgument;

///<summary></summary>
/**
* use to handle document objet on compiler
* @package IGK\System\Runtime\Compiler\Html
*/
class ViewDocumentHandler implements IViewCompilerArgument{
    var $head;
    var $body;
    private $m_changed;


    public function __construct(){
        $this->body = new ViewDocumentBody();
        $this->head = new ViewDocumentHead();
    }

    public function getInstruction($reset=true): ?string {
        $s = $this->m_changed ? sprintf("__set_document_attributes(%s)", [
            "title"=>null
        ]): null;
        if ($reset){
            $this->m_changed = false;
        }
        return $s;
     }
    public function __call($name, $args){
        throw new NotImplementException(__CLASS__."::".$name);
    }
    

    
}