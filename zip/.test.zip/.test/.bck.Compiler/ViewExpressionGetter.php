<?php
// @author: C.A.D. BONDJE DOUE
// @file: ViewExpressionGetter.php
// @date: 20221015 22:47:16
namespace IGK\System\Runtime\Compiler;

use IGK\System\ViewExtractArgHelper;

///<summary></summary>
/**
* 
* @package IGK\System\Runtime\Compiler
*/
class ViewExpressionGetter extends ViewExpressionBase{
    protected function _access_OffsetGet($name){
        $p = ViewExpressionArgHelper::GetVar($name);
        // igk_debug_wln(__FILE__.":".__LINE__,  "bind getter ..... $name ", $p);
        return $p;
        // for concating
        // $args = new ViewExtractArgHelper($name, $p);
        // return $args;
    }
    public function __get($name){
        // for real value
        return $this->getValue($name);
    }
    public function getValue($name){
        // for real value
        $p = ViewExpressionArgHelper::GetVar($name);
        return $p;
    }
    
    public function __toString()
    {
        return 'getter:::';
    }
}