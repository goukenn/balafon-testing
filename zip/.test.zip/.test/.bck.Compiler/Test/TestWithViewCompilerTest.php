<?php

// @author: C.A.D. BONDJE DOUE
// @filename: TestWithViewCompilerTest.php
// @date: 20230106 14:12:55
// @desc: 


class TestWithViewCompiler{

    public function test_get_instructions(){
        $src = implode("\n", [
            '$x = 8;',
            '$y = 9;'
        ]);
        $this->assertEquals(
            json_encode([
                (object)["value"=>'$x = 8;'],
                (object)["value"=>'$y = 9;']
            ]), json_encode(BalafonViewCompilerUtility::GetInstructionsList($src)),
            "failed to get instruction list;"
        );
    }
    public function test_get_class_instructions(){
        $src = implode("\n", [
            'class A(){ }',
            '$y = 9;'
        ]);
        $this->assertFalse(
            BalafonViewCompilerUtility::GetInstructionsList($src),
            "failed to get instruction list;"
        );
    }
    public function test_get_class_func_instructions(){
        $src = implode("\n", [
            '$x = function(){ };',            
        ]);
        $this->assertEquals(
            json_encode([
                (object)["value"=>'$x = function(){ };'], 
            ]), json_encode(BalafonViewCompilerUtility::GetInstructionsList($src)),
            "failed to get empty function list instruct"
        );
    }
    public function test_get_class_func_instructions_2(){
        $src = implode("\n", [
            '$x = function(){ $o= 8; };',            
        ]);
        $this->assertEquals(
            json_encode([
                (object)["value"=>'$x = function(){ $o= 8; };'], 
            ]), json_encode(BalafonViewCompilerUtility::GetInstructionsList($src)),
            "failed to get empty function list instruct"
        );
    }
    public function test_get_class_func_instructions_3(){
        // with try catch
        $src = implode("\n", [
            '$x = function(){ try{ $o= 8; } catch(\Exception $ex){ echo "error"; } finally {  echo "falback"; } };',            
        ]); 
        $this->assertEquals(
            json_encode([
                (object)["value"=>
                '$x = function(){ try{ $o= 8; } catch(\Exception $ex){ echo "error"; } finally {  echo "falback"; } };'], 
            ]), json_encode(BalafonViewCompilerUtility::GetInstructionsList($src)),
            "failed to get empty function list instruct"
        );
    }
    public function test_get_class_func_instructions_4(){
        // with try catch at root 
        $src = implode("\n", [
            'try{ $o= 8; } catch(\Exception $ex){ echo "error"; } finally {  echo "falback"; }   ',            
        ]); 
        $this->assertEquals(
            json_encode([
                (object)["value"=>
                'try{ $o= 8; } catch(\Exception $ex){ echo "error"; } finally {  echo "falback"; }'], 
            ]), json_encode(BalafonViewCompilerUtility::GetInstructionsList($src)),
            "failed to get empty function list instruct"
        );
    }

    public function test_get_func_instructions_at_sub(){
        // with try catch at root 
        $src = implode("\n", [
            'function(){ echo "sub"; }',            
        ]); 
        $this->assertEquals(
            json_encode([
                (object)["value"=>
                'function(){ echo "sub"; };'], 
            ]), json_encode(BalafonViewCompilerUtility::GetInstructionsList($src, false)),
            "failed to get empty function list instruct"
        );
    }
}
