<?php

// balafon --run .test/list_component.php


$g = array_filter(array_map(function($g){
    if (preg_match("/^".IGK_FUNC_NODE_PREFIX."/", $g)){
        return substr($g, strlen(IGK_FUNC_NODE_PREFIX));
    }
} , get_defined_functions()['user']));

sort($g);
print_r($g);
exit;